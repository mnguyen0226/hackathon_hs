export const FormatsData: {[k: string]: ModdedSpeciesFormatsData} = {
	bulbasaur: {
		tier: "LC",
	},
	ivysaur: {
		tier: "NFE",
	},
	venusaur: {
		randomBattleMoves: ["sleeppowder", "leafstorm", "sludgebomb", "substitute", "leechseed"],
		randomDoubleBattleMoves: ["sleeppowder", "gigadrain", "hiddenpowerfire", "hiddenpowerice", "sludgebomb", "powerwhip", "protect"],
		tier: "RU",
		doublesTier: "(DUU)",
	},
	venusaurmega: {
		randomBattleMoves: ["gigadrain", "sludgebomb", "hiddenpowerfire", "synthesis", "leechseed", "earthquake"],
		randomDoubleBattleMoves: ["sleeppowder", "gigadrain", "hiddenpowerfire", "hiddenpowerice", "sludgebomb", "powerwhip", "protect"],
		tier: "UUBL",
		doublesTier: "DUU",
	},
	charmander: {
		tier: "LC",
	},
	charmeleon: {
		tier: "NFE",
	},
	charizard: {
		randomBattleMoves: ["holdhands", "fireblast", "airslash", "earthquake", "roost"],
		randomDoubleBattleMoves: ["heatwave", "fireblast", "airslash", "roost", "protect", "holdhands", "focusblast"],
		tier: "PUBL",
		doublesTier: "(DUU)",
	},
	charizardmegax: {
		randomBattleMoves: ["dragondance", "flareblitz", "dragonclaw", "earthquake", "roost", "willowisp"],
		randomDoubleBattleMoves: ["dragondance", "flareblitz", "dragonclaw", "thunderpunch", "rockslide", "roost"],
		tier: "OU",
		doublesTier: "(DUU)",
	},
	charizardmegay: {
		randomBattleMoves: ["fireblast", "airslash", "roost", "solarbeam", "focusblast", "dragonpulse"],
		randomDoubleBattleMoves: ["heatwave", "fireblast", "airslash", "solarbeam", "focusblast", "protect"],
		tier: "OU",
		doublesTier: "DOU",
	},
	squirtle: {
		tier: "LC",
	},
	wartortle: {
		tier: "NFE",
	},
	blastoise: {
		randomBattleMoves: ["icebeam", "rapidspin", "scald", "toxic", "dragontail", "roar"],
		randomDoubleBattleMoves: ["muddywater", "fakeout", "scald", "followme", "icywind", "protect", "rapidspin"],
		tier: "NU",
		doublesTier: "(DUU)",
	},
	blastoisemega: {
		randomBattleMoves: ["aurasphere", "darkpulse", "icebeam", "rapidspin", "toxic", "waterpulse"],
		randomDoubleBattleMoves: ["muddywater", "icebeam", "fakeout", "waterpulse", "darkpulse", "aurasphere", "protect"],
		tier: "RU",
		doublesTier: "(DUU)",
	},
	caterpie: {
		tier: "LC",
	},
	metapod: {
		tier: "NFE",
	},
	butterfree: {
		randomBattleMoves: ["sleeppowder", "quiverdance", "bugbuzz", "airslash", "energyball"],
		randomDoubleBattleMoves: ["quiverdance", "bugbuzz", "sleeppowder", "airslash", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	weedle: {
		tier: "LC",
	},
	kakuna: {
		tier: "NFE",
	},
	beedrill: {
		randomBattleMoves: ["toxicspikes", "tailwind", "uturn", "endeavor", "poisonjab", "knockoff"],
		randomDoubleBattleMoves: ["uturn", "poisonjab", "knockoff", "protect", "tailwind", "toxicspikes"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	beedrillmega: {
		randomBattleMoves: ["xscissor", "swordsdance", "uturn", "poisonjab", "drillrun", "knockoff"],
		randomDoubleBattleMoves: ["xscissor", "uturn", "poisonjab", "drillrun", "knockoff", "protect"],
		tier: "UU",
		doublesTier: "DUU",
	},
	pidgey: {
		tier: "LC",
	},
	pidgeotto: {
		tier: "NFE",
	},
	pidgeot: {
		randomBattleMoves: ["roost", "bravebird", "heatwave", "return", "uturn", "defog"],
		randomDoubleBattleMoves: ["bravebird", "heatwave", "return", "doubleedge", "uturn", "tailwind", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	pidgeotmega: {
		randomBattleMoves: ["roost", "heatwave", "uturn", "hurricane", "defog"],
		randomDoubleBattleMoves: ["tailwind", "heatwave", "uturn", "hurricane", "protect"],
		tier: "UU",
		doublesTier: "(DUU)",
	},
	rattata: {
		tier: "LC",
	},
	rattataalola: {
		tier: "LC",
	},
	raticate: {
		randomBattleMoves: ["protect", "facade", "stompingtantrum", "suckerpunch", "uturn", "swordsdance"],
		randomDoubleBattleMoves: ["facade", "stompingtantrum", "suckerpunch", "uturn", "crunch", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	raticatealola: {
		randomBattleMoves: ["swordsdance", "return", "suckerpunch", "knockoff", "doubleedge"],
		randomDoubleBattleMoves: ["doubleedge", "suckerpunch", "protect", "knockoff", "uturn"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	raticatealolatotem: {
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	spearow: {
		tier: "LC",
	},
	fearow: {
		randomBattleMoves: ["return", "drillpeck", "doubleedge", "uturn", "pursuit", "drillrun"],
		randomDoubleBattleMoves: ["return", "drillpeck", "doubleedge", "uturn", "quickattack", "drillrun", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	ekans: {
		tier: "LC",
	},
	arbok: {
		randomBattleMoves: ["coil", "gunkshot", "suckerpunch", "aquatail", "earthquake", "rest"],
		randomDoubleBattleMoves: ["gunkshot", "suckerpunch", "aquatail", "stompingtantrum", "coil", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	pichu: {
		tier: "LC",
	},
	pikachu: {
		randomBattleMoves: ["volttackle", "voltswitch", "grassknot", "hiddenpowerice", "knockoff", "irontail"],
		randomDoubleBattleMoves: ["fakeout", "volttackle", "voltswitch", "grassknot", "hiddenpowerice", "encore", "knockoff", "protect"],
		tier: "NFE",
	},
	pikachuoriginal: {
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	pikachuhoenn: {
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	pikachusinnoh: {
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	pikachuunova: {
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	pikachukalos: {
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	pikachualola: {
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	pikachupartner: {
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	raichu: {
		randomBattleMoves: ["nastyplot", "encore", "thunderbolt", "grassknot", "hiddenpowerice", "focusblast", "voltswitch"],
		randomDoubleBattleMoves: ["fakeout", "encore", "thunderbolt", "grassknot", "hiddenpowerice", "focusblast", "voltswitch", "protect"],
		tier: "(PU)",
		doublesTier: "DUU",
	},
	raichualola: {
		randomBattleMoves: ["nastyplot", "thunderbolt", "psyshock", "focusblast", "voltswitch", "surf"],
		randomDoubleBattleMoves: ["thunderbolt", "fakeout", "nastyplot", "grassknot", "psyshock", "protect", "voltswitch"],
		tier: "PU",
		doublesTier: "(DUU)",
	},
	sandshrew: {
		tier: "LC",
	},
	sandshrewalola: {
		tier: "LC",
	},
	sandslash: {
		randomBattleMoves: ["earthquake", "knockoff", "rapidspin", "stealthrock", "stoneedge", "swordsdance", "toxic"],
		randomDoubleBattleMoves: ["earthquake", "stoneedge", "swordsdance", "knockoff", "protect", "stealthrock"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	sandslashalola: {
		randomBattleMoves: ["swordsdance", "iciclecrash", "ironhead", "earthquake", "rapidspin", "stealthrock", "knockoff"],
		randomDoubleBattleMoves: ["protect", "swordsdance", "iciclecrash", "ironhead", "drillrun"],
		tier: "PU",
		doublesTier: "(DUU)",
	},
	nidoranf: {
		tier: "LC",
	},
	nidorina: {
		tier: "NFE",
	},
	nidoqueen: {
		randomBattleMoves: ["toxicspikes", "stealthrock", "fireblast", "icebeam", "earthpower", "sludgewave"],
		randomDoubleBattleMoves: ["protect", "icebeam", "earthpower", "sludgebomb", "stealthrock"],
		tier: "RU",
		doublesTier: "(DUU)",
	},
	nidoranm: {
		tier: "LC",
	},
	nidorino: {
		tier: "NFE",
	},
	nidoking: {
		randomBattleMoves: ["substitute", "fireblast", "icebeam", "earthpower", "sludgewave", "superpower"],
		randomDoubleBattleMoves: ["protect", "fireblast", "icebeam", "earthpower", "sludgebomb"],
		tier: "UU",
		doublesTier: "(DUU)",
	},
	cleffa: {
		tier: "LC",
	},
	clefairy: {
		tier: "PU",
		doublesTier: "NFE",
	},
	clefable: {
		randomBattleMoves: ["calmmind", "softboiled", "fireblast", "moonblast", "stealthrock", "thunderwave"],
		randomDoubleBattleMoves: ["thunderwave", "fireblast", "helpinghand", "followme", "protect", "moonblast", "dazzlinggleam", "softboiled"],
		tier: "OU",
		doublesTier: "DUU",
	},
	vulpix: {
		tier: "LC Uber",
	},
	vulpixalola: {
		tier: "LC",
	},
	ninetales: {
		randomBattleMoves: ["fireblast", "willowisp", "solarbeam", "nastyplot", "substitute", "psyshock"],
		randomDoubleBattleMoves: ["heatwave", "fireblast", "willowisp", "solarbeam", "nastyplot", "protect"],
		tier: "RU",
		doublesTier: "DUU",
	},
	ninetalesalola: {
		randomBattleMoves: ["nastyplot", "blizzard", "moonblast", "substitute", "hiddenpowerfire", "freezedry", "auroraveil"],
		randomDoubleBattleMoves: ["blizzard", "moonblast", "protect", "hiddenpowerfire", "freezedry", "auroraveil", "encore"],
		tier: "UUBL",
		doublesTier: "DOU",
	},
	igglybuff: {
		tier: "LC",
	},
	jigglypuff: {
		tier: "NFE",
	},
	wigglytuff: {
		randomBattleMoves: ["reflect", "lightscreen", "healbell", "stealthrock", "fireblast", "dazzlinggleam"],
		randomDoubleBattleMoves: ["thunderwave", "stealthrock", "protect", "dazzlinggleam", "fireblast", "hypervoice"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	zubat: {
		tier: "LC",
	},
	golbat: {
		tier: "NU",
		doublesTier: "NFE",
	},
	crobat: {
		randomBattleMoves: ["bravebird", "roost", "toxic", "taunt", "defog", "uturn", "superfang"],
		randomDoubleBattleMoves: ["bravebird", "taunt", "tailwind", "uturn", "protect", "superfang"],
		tier: "UU",
		doublesTier: "(DUU)",
	},
	oddish: {
		tier: "LC",
	},
	gloom: {
		tier: "NFE",
	},
	vileplume: {
		randomBattleMoves: ["gigadrain", "sludgebomb", "sleeppowder", "hiddenpowerfire", "aromatherapy", "strengthsap"],
		randomDoubleBattleMoves: ["energyball", "sludgebomb", "sleeppowder", "strengthsap", "protect", "hiddenpowerfire"],
		tier: "NUBL",
		doublesTier: "(DUU)",
	},
	bellossom: {
		randomBattleMoves: ["gigadrain", "hiddenpowerground", "moonblast", "quiverdance", "sleeppowder", "strengthsap"],
		randomDoubleBattleMoves: ["energyball", "quiverdance", "sleeppowder", "strengthsap", "moonblast"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	paras: {
		tier: "LC",
	},
	parasect: {
		randomBattleMoves: ["spore", "substitute", "leechlife", "seedbomb", "leechseed", "knockoff"],
		randomDoubleBattleMoves: ["spore", "leechlife", "seedbomb", "ragepowder", "leechseed", "protect", "knockoff", "wideguard"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	venonat: {
		tier: "LC",
	},
	venomoth: {
		randomBattleMoves: ["sleeppowder", "quiverdance", "bugbuzz", "sludgebomb", "substitute"],
		randomDoubleBattleMoves: ["sleeppowder", "ragepowder", "quiverdance", "protect", "bugbuzz", "sludgebomb"],
		tier: "RUBL",
		doublesTier: "(DUU)",
	},
	diglett: {
		tier: "LC",
	},
	diglettalola: {
		tier: "LC",
	},
	dugtrio: {
		randomBattleMoves: ["earthquake", "stoneedge", "stealthrock", "suckerpunch", "reversal", "substitute", "memento"],
		randomDoubleBattleMoves: ["earthquake", "rockslide", "protect", "suckerpunch", "stoneedge"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	dugtrioalola: {
		randomBattleMoves: ["earthquake", "ironhead", "substitute", "toxic", "stoneedge", "suckerpunch", "stealthrock"],
		randomDoubleBattleMoves: ["earthquake", "ironhead", "protect", "rockslide", "stoneedge", "suckerpunch"],
		tier: "PU",
		doublesTier: "(DUU)",
	},
	meowth: {
		tier: "LC",
	},
	meowthalola: {
		tier: "LC",
	},
	persian: {
		randomBattleMoves: ["fakeout", "uturn", "taunt", "return", "knockoff"],
		randomDoubleBattleMoves: ["fakeout", "uturn", "knockoff", "taunt", "return", "hypnosis", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	persianalola: {
		randomBattleMoves: ["nastyplot", "darkpulse", "powergem", "hypnosis", "hiddenpowerfighting"],
		randomDoubleBattleMoves: ["fakeout", "foulplay", "hiddenpowerfighting", "snarl", "icywind", "partingshot", "protect"],
		tier: "PU",
		doublesTier: "(DUU)",
	},
	psyduck: {
		tier: "LC",
	},
	golduck: {
		randomBattleMoves: ["hydropump", "scald", "icebeam", "psyshock", "encore", "calmmind", "substitute"],
		randomDoubleBattleMoves: ["hydropump", "scald", "icebeam", "focusblast", "encore", "calmmind", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	mankey: {
		tier: "LC",
	},
	primeape: {
		randomBattleMoves: ["closecombat", "uturn", "icepunch", "stoneedge", "encore", "earthquake", "gunkshot"],
		randomDoubleBattleMoves: ["closecombat", "uturn", "icepunch", "rockslide", "stompingtantrum", "poisonjab", "protect", "taunt", "stoneedge"],
		tier: "PU",
		doublesTier: "(DUU)",
	},
	growlithe: {
		tier: "LC",
	},
	arcanine: {
		randomBattleMoves: ["flareblitz", "wildcharge", "extremespeed", "closecombat", "morningsun", "willowisp", "toxic", "crunch", "roar"],
		randomDoubleBattleMoves: ["flareblitz", "wildcharge", "closecombat", "willowisp", "snarl", "protect", "extremespeed"],
		tier: "RU",
		doublesTier: "DUU",
	},
	poliwag: {
		tier: "LC",
	},
	poliwhirl: {
		tier: "NFE",
	},
	poliwrath: {
		randomBattleMoves: ["hydropump", "focusblast", "icepunch", "rest", "sleeptalk", "scald", "circlethrow", "raindance"],
		randomDoubleBattleMoves: ["encore", "scald", "protect", "icywind", "circlethrow", "toxic", "superpower"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	politoed: {
		randomBattleMoves: ["scald", "toxic", "encore", "perishsong", "protect", "hypnosis", "rest"],
		randomDoubleBattleMoves: ["scald", "hypnosis", "icywind", "encore", "helpinghand", "protect"],
		tier: "(PU)",
		doublesTier: "DOU",
	},
	abra: {
		tier: "LC",
	},
	kadabra: {
		tier: "NFE",
	},
	alakazam: {
		randomBattleMoves: ["psyshock", "psychic", "focusblast", "shadowball", "hiddenpowerice", "hiddenpowerfire"],
		randomDoubleBattleMoves: ["protect", "psychic", "focusblast", "shadowball", "encore", "dazzlinggleam"],
		tier: "UUBL",
		doublesTier: "(DUU)",
	},
	alakazammega: {
		randomBattleMoves: ["calmmind", "psyshock", "focusblast", "shadowball", "encore", "substitute"],
		randomDoubleBattleMoves: ["protect", "psychic", "focusblast", "shadowball", "encore", "calmmind"],
		tier: "OU",
		doublesTier: "(DUU)",
	},
	machop: {
		tier: "LC",
	},
	machoke: {
		tier: "NFE",
	},
	machamp: {
		randomBattleMoves: ["dynamicpunch", "icepunch", "stoneedge", "bulletpunch", "knockoff", "substitute"],
		randomDoubleBattleMoves: ["protect", "closecombat", "facade", "stoneedge", "bulletpunch", "knockoff", "wideguard"],
		tier: "RU",
		doublesTier: "(DUU)",
	},
	bellsprout: {
		tier: "LC",
	},
	weepinbell: {
		tier: "NFE",
	},
	victreebel: {
		randomBattleMoves: ["sleeppowder", "sludgebomb", "gigadrain", "hiddenpowerfire", "suckerpunch", "swordsdance", "powerwhip", "knockoff"],
		randomDoubleBattleMoves: ["sleeppowder", "sunnyday", "growth", "solarbeam", "sludgebomb", "weatherball", "suckerpunch", "powerwhip", "knockoff", "protect"],
		tier: "PU",
		doublesTier: "(DUU)",
	},
	tentacool: {
		tier: "LC",
	},
	tentacruel: {
		randomBattleMoves: ["toxicspikes", "rapidspin", "scald", "sludgebomb", "acidspray", "knockoff"],
		randomDoubleBattleMoves: ["muddywater", "scald", "sludgebomb", "acidspray", "knockoff", "protect", "rapidspin"],
		tier: "UU",
		doublesTier: "(DUU)",
	},
	geodude: {
		tier: "LC",
	},
	geodudealola: {
		tier: "LC",
	},
	graveler: {
		tier: "NFE",
	},
	graveleralola: {
		tier: "NFE",
	},
	golem: {
		randomBattleMoves: ["stealthrock", "earthquake", "explosion", "suckerpunch", "toxic", "rockblast"],
		randomDoubleBattleMoves: ["rockslide", "earthquake", "stoneedge", "suckerpunch", "protect", "stealthrock"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	golemalola: {
		randomBattleMoves: ["earthquake", "firepunch", "stealthrock", "stoneedge", "wildcharge"],
		randomDoubleBattleMoves: ["doubleedge", "stoneedge", "rockslide", "stompingtantrum", "protect", "stealthrock"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	ponyta: {
		tier: "LC",
	},
	rapidash: {
		randomBattleMoves: ["flareblitz", "wildcharge", "morningsun", "highhorsepower", "willowisp"],
		randomDoubleBattleMoves: ["flareblitz", "wildcharge", "protect", "hypnosis", "highhorsepower", "willowisp"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	slowpoke: {
		tier: "LC",
	},
	slowbro: {
		randomBattleMoves: ["scald", "toxic", "thunderwave", "psyshock", "fireblast", "icebeam", "slackoff"],
		randomDoubleBattleMoves: ["scald", "psychic", "thunderwave", "slackoff", "protect", "psyshock", "toxic"],
		tier: "RU",
		doublesTier: "(DUU)",
	},
	slowbromega: {
		randomBattleMoves: ["calmmind", "fireblast", "psyshock", "scald", "slackoff"],
		randomDoubleBattleMoves: ["scald", "fireblast", "icebeam", "psychic", "slackoff", "trickroom", "protect", "psyshock"],
		tier: "RUBL",
		doublesTier: "(DUU)",
	},
	slowking: {
		randomBattleMoves: ["dragontail", "fireblast", "grassknot", "icebeam", "nastyplot", "psyshock", "scald", "slackoff", "thunderwave", "toxic", "trickroom"],
		randomDoubleBattleMoves: ["scald", "fireblast", "psychic", "trickroom", "protect", "psyshock"],
		tier: "NU",
		doublesTier: "(DUU)",
	},
	magnemite: {
		tier: "LC",
	},
	magneton: {
		tier: "UU",
		doublesTier: "NFE",
	},
	magnezone: {
		randomBattleMoves: ["thunderbolt", "substitute", "flashcannon", "hiddenpowerfire", "voltswitch"],
		randomDoubleBattleMoves: ["thunderbolt", "flashcannon", "voltswitch", "protect", "electroweb", "hiddenpowerfire"],
		tier: "OU",
		doublesTier: "(DUU)",
	},
	farfetchd: {
		randomBattleMoves: ["bravebird", "swordsdance", "return", "leafblade", "roost", "knockoff"],
		randomDoubleBattleMoves: ["bravebird", "swordsdance", "return", "leafblade", "protect", "knockoff"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	doduo: {
		tier: "LC",
	},
	dodrio: {
		randomBattleMoves: ["bravebird", "jumpkick", "knockoff", "quickattack", "return", "swordsdance"],
		randomDoubleBattleMoves: ["bravebird", "return", "swordsdance", "quickattack", "knockoff", "protect"],
		tier: "PU",
		doublesTier: "(DUU)",
	},
	seel: {
		tier: "LC",
	},
	dewgong: {
		randomBattleMoves: ["surf", "icebeam", "perishsong", "encore", "toxic", "protect"],
		randomDoubleBattleMoves: ["liquidation", "icebeam", "protect", "helpinghand", "fakeout", "encore", "icywind", "toxic"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	grimer: {
		tier: "LC",
	},
	grimeralola: {
		tier: "LC",
	},
	muk: {
		randomBattleMoves: ["curse", "gunkshot", "poisonjab", "shadowsneak", "icepunch", "firepunch", "memento"],
		randomDoubleBattleMoves: ["gunkshot", "poisonjab", "shadowsneak", "protect", "icepunch", "firepunch"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	mukalola: {
		randomBattleMoves: ["curse", "gunkshot", "knockoff", "poisonjab", "shadowsneak", "pursuit", "icepunch", "firepunch"],
		randomDoubleBattleMoves: ["gunkshot", "knockoff", "stoneedge", "snarl", "protect", "poisonjab", "shadowsneak"],
		tier: "UU",
		doublesTier: "DUU",
	},
	shellder: {
		tier: "LC",
	},
	cloyster: {
		randomBattleMoves: ["hydropump", "iciclespear", "rapidspin", "rockblast", "shellsmash", "spikes"],
		randomDoubleBattleMoves: ["shellsmash", "hydropump", "rockblast", "iciclespear", "protect"],
		tier: "RU",
		doublesTier: "(DUU)",
	},
	gastly: {
		tier: "LC",
	},
	haunter: {
		tier: "PU",
		doublesTier: "NFE",
	},
	gengar: {
		randomBattleMoves: ["shadowball", "sludgewave", "focusblast", "substitute", "disable", "painsplit", "willowisp"],
		randomDoubleBattleMoves: ["shadowball", "sludgebomb", "focusblast", "taunt", "willowisp", "protect"],
		tier: "UU",
		doublesTier: "DUU",
	},
	gengarmega: {
		randomBattleMoves: ["shadowball", "sludgewave", "focusblast", "taunt", "destinybond", "disable", "perishsong", "protect"],
		randomDoubleBattleMoves: ["shadowball", "sludgebomb", "focusblast", "disable", "hypnosis", "willowisp", "protect"],
		tier: "Uber",
		doublesTier: "DUber",
	},
	onix: {
		tier: "LC",
	},
	steelix: {
		randomBattleMoves: ["stealthrock", "earthquake", "ironhead", "roar", "toxic", "rockslide"],
		randomDoubleBattleMoves: ["stealthrock", "earthquake", "heavyslam", "headsmash", "protect", "wideguard"],
		tier: "NU",
		doublesTier: "(DUU)",
	},
	steelixmega: {
		randomBattleMoves: ["stealthrock", "earthquake", "heavyslam", "roar", "toxic", "dragontail"],
		randomDoubleBattleMoves: ["stealthrock", "earthquake", "heavyslam", "rockslide", "protect"],
		tier: "UU",
		doublesTier: "(DUU)",
	},
	drowzee: {
		tier: "LC",
	},
	hypno: {
		randomBattleMoves: ["psychic", "seismictoss", "foulplay", "wish", "protect", "thunderwave", "toxic"],
		randomDoubleBattleMoves: ["psychic", "seismictoss", "thunderwave", "protect", "hypnosis"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	krabby: {
		tier: "LC",
	},
	kingler: {
		randomBattleMoves: ["liquidation", "xscissor", "rockslide", "swordsdance", "agility", "superpower", "knockoff"],
		randomDoubleBattleMoves: ["agility", "liquidation", "xscissor", "rockslide", "knockoff", "protect", "wideguard"],
		tier: "PUBL",
		doublesTier: "(DUU)",
	},
	voltorb: {
		tier: "LC",
	},
	electrode: {
		randomBattleMoves: ["voltswitch", "thunderbolt", "taunt", "foulplay", "hiddenpowergrass", "signalbeam"],
		randomDoubleBattleMoves: ["voltswitch", "thunderbolt", "taunt", "foulplay", "protect", "thunderwave"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	exeggcute: {
		tier: "LC",
	},
	exeggutor: {
		randomBattleMoves: ["substitute", "leechseed", "gigadrain", "psychic", "sleeppowder", "hiddenpowerfire"],
		randomDoubleBattleMoves: ["substitute", "leechseed", "energyball", "psychic", "sleeppowder", "hiddenpowerfire", "protect", "trickroom"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	exeggutoralola: {
		randomBattleMoves: ["dracometeor", "leafstorm", "flamethrower", "gigadrain", "trickroom"],
		randomDoubleBattleMoves: ["dracometeor", "leafstorm", "protect", "flamethrower", "trickroom", "woodhammer", "dragonhammer"],
		tier: "NU",
		doublesTier: "(DUU)",
	},
	cubone: {
		tier: "LC",
	},
	marowak: {
		randomBattleMoves: ["bonemerang", "earthquake", "knockoff", "doubleedge", "stoneedge", "stealthrock", "substitute"],
		randomDoubleBattleMoves: ["bonemerang", "doubleedge", "rockslide", "firepunch", "protect", "swordsdance", "stealthrock"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	marowakalola: {
		randomBattleMoves: ["flamecharge", "shadowbone", "bonemerang", "willowisp", "stoneedge", "flareblitz", "substitute"],
		randomDoubleBattleMoves: ["shadowbone", "bonemerang", "willowisp", "stoneedge", "flareblitz", "protect"],
		tier: "RU",
		doublesTier: "DUU",
	},
	marowakalolatotem: {
		tier: "RU",
		doublesTier: "DUU",
	},
	tyrogue: {
		tier: "LC",
	},
	hitmonlee: {
		randomBattleMoves: ["highjumpkick", "knockoff", "stoneedge", "rapidspin", "machpunch", "poisonjab", "fakeout"],
		randomDoubleBattleMoves: ["knockoff", "rockslide", "machpunch", "fakeout", "closecombat", "protect"],
		tier: "NU",
		doublesTier: "(DUU)",
	},
	hitmonchan: {
		randomBattleMoves: ["bulkup", "drainpunch", "icepunch", "firepunch", "machpunch", "rapidspin"],
		randomDoubleBattleMoves: ["fakeout", "drainpunch", "icepunch", "firepunch", "machpunch", "protect"],
		tier: "PU",
		doublesTier: "(DUU)",
	},
	hitmontop: {
		randomBattleMoves: ["suckerpunch", "stoneedge", "rapidspin", "closecombat", "toxic"],
		randomDoubleBattleMoves: ["fakeout", "feint", "suckerpunch", "closecombat", "helpinghand", "machpunch", "wideguard", "rapidspin"],
		tier: "NU",
		doublesTier: "DUU",
	},
	lickitung: {
		tier: "LC",
	},
	lickilicky: {
		randomBattleMoves: ["wish", "protect", "bodyslam", "knockoff", "dragontail", "healbell", "swordsdance", "explosion", "earthquake", "powerwhip"],
		randomDoubleBattleMoves: ["protect", "dragontail", "knockoff", "bodyslam", "powerwhip", "stompingtantrum", "explosion"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	koffing: {
		tier: "LC",
	},
	weezing: {
		randomBattleMoves: ["painsplit", "sludgebomb", "willowisp", "fireblast", "protect", "toxicspikes"],
		randomDoubleBattleMoves: ["protect", "sludgebomb", "willowisp", "fireblast", "toxicspikes", "painsplit"],
		tier: "NU",
		doublesTier: "(DUU)",
	},
	rhyhorn: {
		tier: "LC",
	},
	rhydon: {
		tier: "NU",
		doublesTier: "NFE",
	},
	rhyperior: {
		randomBattleMoves: ["stoneedge", "earthquake", "icepunch", "megahorn", "stealthrock", "rockblast", "rockpolish", "dragontail"],
		randomDoubleBattleMoves: ["stoneedge", "earthquake", "megahorn", "stealthrock", "rockslide", "icepunch", "protect"],
		tier: "RU",
		doublesTier: "(DUU)",
	},
	happiny: {
		tier: "LC",
	},
	chansey: {
		randomBattleMoves: ["softboiled", "healbell", "stealthrock", "thunderwave", "toxic", "seismictoss", "wish"],
		randomDoubleBattleMoves: ["toxic", "thunderwave", "helpinghand", "softboiled", "seismictoss", "protect"],
		tier: "OU",
		doublesTier: "NFE",
	},
	blissey: {
		randomBattleMoves: ["toxic", "flamethrower", "seismictoss", "softboiled", "healbell", "protect", "thunderwave", "stealthrock"],
		randomDoubleBattleMoves: ["softboiled", "protect", "toxic", "seismictoss", "helpinghand", "thunderwave"],
		tier: "UU",
		doublesTier: "(DUU)",
	},
	tangela: {
		tier: "PU",
		doublesTier: "LC Uber",
	},
	tangrowth: {
		randomBattleMoves: ["gigadrain", "leafstorm", "knockoff", "earthquake", "hiddenpowerfire", "rockslide", "sleeppowder", "synthesis"],
		randomDoubleBattleMoves: ["gigadrain", "sleeppowder", "hiddenpowerice", "leechseed", "knockoff", "ragepowder", "focusblast", "protect", "powerwhip", "earthquake"],
		tier: "OU",
		doublesTier: "(DUU)",
	},
	kangaskhan: {
		randomBattleMoves: ["return", "suckerpunch", "earthquake", "drainpunch", "crunch", "fakeout"],
		randomDoubleBattleMoves: ["fakeout", "return", "suckerpunch", "earthquake", "doubleedge", "drainpunch", "crunch", "protect"],
		tier: "PU",
		doublesTier: "(DUU)",
	},
	kangaskhanmega: {
		randomBattleMoves: ["fakeout", "seismictoss", "bodyslam", "suckerpunch", "crunch"],
		randomDoubleBattleMoves: ["fakeout", "return", "suckerpunch", "earthquake", "poweruppunch", "drainpunch", "protect"],
		tier: "Uber",
		doublesTier: "DUber",
	},
	horsea: {
		tier: "LC",
	},
	seadra: {
		tier: "NFE",
	},
	kingdra: {
		randomBattleMoves: ["raindance", "hydropump", "dracometeor", "icebeam", "waterfall"],
		randomDoubleBattleMoves: ["hydropump", "icebeam", "raindance", "dracometeor", "dragonpulse", "muddywater", "protect"],
		tier: "NUBL",
		doublesTier: "DOU",
	},
	goldeen: {
		tier: "LC",
	},
	seaking: {
		randomBattleMoves: ["waterfall", "megahorn", "knockoff", "drillrun", "scald", "icebeam"],
		randomDoubleBattleMoves: ["waterfall", "megahorn", "knockoff", "drillrun", "icywind", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	staryu: {
		tier: "LC",
	},
	starmie: {
		randomBattleMoves: ["thunderbolt", "icebeam", "rapidspin", "recover", "psyshock", "scald", "hydropump"],
		randomDoubleBattleMoves: ["thunderbolt", "icebeam", "protect", "psychic", "psyshock", "scald", "hydropump"],
		tier: "UU",
		doublesTier: "DUU",
	},
	mimejr: {
		tier: "LC",
	},
	mrmime: {
		randomBattleMoves: ["nastyplot", "psyshock", "dazzlinggleam", "shadowball", "focusblast", "healingwish", "encore"],
		randomDoubleBattleMoves: ["fakeout", "thunderwave", "hiddenpowerfighting", "psychic", "thunderbolt", "encore", "icywind", "protect", "wideguard", "dazzlinggleam", "followme"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	scyther: {
		randomBattleMoves: ["swordsdance", "roost", "bugbite", "quickattack", "brickbreak", "aerialace", "uturn", "knockoff"],
		randomDoubleBattleMoves: ["swordsdance", "protect", "bugbite", "brickbreak", "aerialace", "feint", "uturn", "knockoff"],
		tier: "PU",
		doublesTier: "LC Uber",
	},
	scizor: {
		randomBattleMoves: ["swordsdance", "bulletpunch", "bugbite", "superpower", "uturn", "pursuit", "knockoff"],
		randomDoubleBattleMoves: ["swordsdance", "bulletpunch", "bugbite", "superpower", "uturn", "protect", "feint", "knockoff"],
		tier: "UU",
		doublesTier: "(DUU)",
	},
	scizormega: {
		randomBattleMoves: ["swordsdance", "roost", "bulletpunch", "bugbite", "superpower", "uturn", "defog", "knockoff"],
		randomDoubleBattleMoves: ["swordsdance", "roost", "bulletpunch", "bugbite", "superpower", "uturn", "protect", "feint", "knockoff"],
		tier: "OU",
		doublesTier: "DUU",
	},
	smoochum: {
		tier: "LC",
	},
	jynx: {
		randomBattleMoves: ["icebeam", "psychic", "focusblast", "trick", "nastyplot", "lovelykiss", "substitute", "psyshock"],
		randomDoubleBattleMoves: ["icebeam", "psychic", "focusblast", "protect", "lovelykiss", "psyshock", "nastyplot"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	elekid: {
		tier: "LC",
	},
	electabuzz: {
		tier: "NFE",
	},
	electivire: {
		randomBattleMoves: ["wildcharge", "crosschop", "icepunch", "flamethrower", "earthquake", "voltswitch"],
		randomDoubleBattleMoves: ["wildcharge", "crosschop", "icepunch", "flamethrower", "stompingtantrum", "protect", "followme"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	magby: {
		tier: "LC",
	},
	magmar: {
		tier: "NFE",
	},
	magmortar: {
		randomBattleMoves: ["fireblast", "focusblast", "hiddenpowergrass", "hiddenpowerice", "thunderbolt", "earthquake", "substitute"],
		randomDoubleBattleMoves: ["fireblast", "taunt", "hiddenpowergrass", "hiddenpowerice", "thunderbolt", "heatwave", "willowisp", "protect", "followme"],
		tier: "NU",
		doublesTier: "(DUU)",
	},
	pinsir: {
		randomBattleMoves: ["earthquake", "xscissor", "closecombat", "stoneedge", "stealthrock", "knockoff"],
		randomDoubleBattleMoves: ["protect", "feint", "xscissor", "closecombat", "rockslide", "knockoff"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	pinsirmega: {
		randomBattleMoves: ["swordsdance", "earthquake", "closecombat", "quickattack", "return"],
		randomDoubleBattleMoves: ["feint", "protect", "swordsdance", "closecombat", "quickattack", "return", "rockslide"],
		tier: "UUBL",
		doublesTier: "(DUU)",
	},
	tauros: {
		randomBattleMoves: ["bodyslam", "earthquake", "zenheadbutt", "rockslide", "doubleedge"],
		randomDoubleBattleMoves: ["return", "stompingtantrum", "zenheadbutt", "rockslide", "stoneedge", "protect", "doubleedge"],
		tier: "PUBL",
		doublesTier: "(DUU)",
	},
	magikarp: {
		tier: "LC",
	},
	gyarados: {
		randomBattleMoves: ["dragondance", "waterfall", "earthquake", "bounce", "dragontail", "stoneedge", "substitute"],
		randomDoubleBattleMoves: ["dragondance", "waterfall", "bounce", "protect", "thunderwave", "stoneedge"],
		tier: "UUBL",
		doublesTier: "DUU",
	},
	gyaradosmega: {
		randomBattleMoves: ["dragondance", "waterfall", "earthquake", "substitute", "icefang", "crunch"],
		randomDoubleBattleMoves: ["dragondance", "waterfall", "taunt", "protect", "thunderwave", "icefang", "crunch"],
		tier: "OU",
		doublesTier: "DUU",
	},
	lapras: {
		randomBattleMoves: ["icebeam", "thunderbolt", "healbell", "toxic", "hydropump", "substitute"],
		randomDoubleBattleMoves: ["freezedry", "hydropump", "helpinghand", "protect", "iceshard", "icywind"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	ditto: {
		randomBattleMoves: ["transform"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	eevee: {
		tier: "LC",
	},
	vaporeon: {
		randomBattleMoves: ["wish", "protect", "scald", "roar", "icebeam", "healbell"],
		randomDoubleBattleMoves: ["helpinghand", "protect", "scald", "muddywater", "icywind", "toxic"],
		tier: "NU",
		doublesTier: "(DUU)",
	},
	jolteon: {
		randomBattleMoves: ["thunderbolt", "voltswitch", "hiddenpowerice", "shadowball", "signalbeam"],
		randomDoubleBattleMoves: ["thunderbolt", "voltswitch", "hiddenpowergrass", "hiddenpowerice", "helpinghand", "protect", "signalbeam"],
		tier: "RU",
		doublesTier: "(DUU)",
	},
	flareon: {
		randomBattleMoves: ["flamecharge", "facade", "flareblitz", "superpower", "quickattack"],
		randomDoubleBattleMoves: ["flamecharge", "facade", "flareblitz", "superpower", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	espeon: {
		randomBattleMoves: ["psychic", "psyshock", "substitute", "shadowball", "calmmind", "morningsun", "dazzlinggleam"],
		randomDoubleBattleMoves: ["psychic", "shadowball", "calmmind", "helpinghand", "protect", "dazzlinggleam"],
		tier: "RU",
		doublesTier: "(DUU)",
	},
	umbreon: {
		randomBattleMoves: ["wish", "protect", "healbell", "toxic", "foulplay"],
		randomDoubleBattleMoves: ["moonlight", "protect", "snarl", "foulplay", "helpinghand"],
		tier: "RU",
		doublesTier: "(DUU)",
	},
	leafeon: {
		randomBattleMoves: ["swordsdance", "leafblade", "healbell", "xscissor", "synthesis", "knockoff"],
		randomDoubleBattleMoves: ["swordsdance", "leafblade", "xscissor", "protect", "helpinghand", "knockoff"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	glaceon: {
		randomBattleMoves: ["icebeam", "hiddenpowerground", "shadowball", "healbell", "wish", "protect", "toxic"],
		randomDoubleBattleMoves: ["icebeam", "hiddenpowerground", "protect", "helpinghand", "toxic"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	porygon: {
		tier: "LC Uber",
	},
	porygon2: {
		randomBattleMoves: ["triattack", "icebeam", "discharge", "recover", "toxic"],
		randomDoubleBattleMoves: ["triattack", "icebeam", "thunderbolt", "protect", "recover", "allyswitch", "thunderwave"],
		tier: "RU",
		doublesTier: "DOU",
	},
	porygonz: {
		randomBattleMoves: ["triattack", "shadowball", "icebeam", "thunderbolt", "trick", "nastyplot"],
		randomDoubleBattleMoves: ["protect", "triattack", "darkpulse", "icebeam", "thunderbolt", "trick", "nastyplot"],
		tier: "UUBL",
		doublesTier: "DUU",
	},
	omanyte: {
		tier: "LC",
	},
	omastar: {
		randomBattleMoves: ["shellsmash", "scald", "icebeam", "earthpower", "spikes", "stealthrock", "hydropump"],
		randomDoubleBattleMoves: ["shellsmash", "muddywater", "icebeam", "earthpower", "hiddenpowerelectric", "protect", "hydropump"],
		tier: "PU",
		doublesTier: "(DUU)",
	},
	kabuto: {
		tier: "LC",
	},
	kabutops: {
		randomBattleMoves: ["aquajet", "stoneedge", "rapidspin", "swordsdance", "liquidation", "knockoff"],
		randomDoubleBattleMoves: ["aquajet", "stoneedge", "protect", "rockslide", "swordsdance", "liquidation", "knockoff"],
		tier: "PU",
		doublesTier: "(DUU)",
	},
	aerodactyl: {
		randomBattleMoves: ["stealthrock", "taunt", "defog", "roost", "stoneedge", "earthquake", "doubleedge", "pursuit"],
		randomDoubleBattleMoves: ["wideguard", "stoneedge", "rockslide", "earthquake", "protect", "skydrop", "tailwind"],
		tier: "NU",
		doublesTier: "(DUU)",
	},
	aerodactylmega: {
		randomBattleMoves: ["honeclaws", "stoneedge", "aerialace", "aquatail", "earthquake", "firefang", "roost"],
		randomDoubleBattleMoves: ["wideguard", "stoneedge", "rockslide", "aquatail", "protect", "skydrop", "tailwind"],
		tier: "UU",
		doublesTier: "DUU",
	},
	munchlax: {
		tier: "LC",
	},
	snorlax: {
		randomBattleMoves: ["rest", "curse", "sleeptalk", "bodyslam", "earthquake", "return", "firepunch", "crunch", "pursuit", "whirlwind"],
		randomDoubleBattleMoves: ["curse", "protect", "bodyslam", "rest", "highhorsepower", "return", "crunch"],
		tier: "RU",
		doublesTier: "DUber",
	},
	articuno: {
		randomBattleMoves: ["freezedry", "hurricane", "roost", "substitute", "toxic"],
		randomDoubleBattleMoves: ["freezedry", "roost", "protect", "hurricane", "tailwind"],
		tier: "PU",
		doublesTier: "(DUU)",
	},
	zapdos: {
		randomBattleMoves: ["thunderbolt", "heatwave", "hiddenpowerice", "roost", "toxic", "uturn", "defog"],
		randomDoubleBattleMoves: ["thunderbolt", "heatwave", "roost", "hiddenpowergrass", "hiddenpowerice", "tailwind", "protect"],
		tier: "OU",
		doublesTier: "DOU",
	},
	moltres: {
		randomBattleMoves: ["fireblast", "roost", "substitute", "toxic", "willowisp", "hurricane"],
		randomDoubleBattleMoves: ["fireblast", "airslash", "protect", "uturn", "willowisp", "hurricane", "heatwave", "tailwind"],
		tier: "UU",
		doublesTier: "(DUU)",
	},
	dratini: {
		tier: "LC",
	},
	dragonair: {
		tier: "NFE",
	},
	dragonite: {
		randomBattleMoves: ["dragondance", "earthquake", "extremespeed", "firepunch", "fly", "outrage"],
		randomDoubleBattleMoves: ["dragondance", "firepunch", "extremespeed", "dragonclaw", "roost", "superpower", "protect", "fly"],
		tier: "UUBL",
		doublesTier: "(DUU)",
	},
	mewtwo: {
		randomBattleMoves: ["psystrike", "aurasphere", "fireblast", "icebeam", "calmmind", "recover"],
		randomDoubleBattleMoves: ["psystrike", "aurasphere", "fireblast", "icebeam", "calmmind", "protect"],
		tier: "Uber",
		doublesTier: "DUber",
	},
	mewtwomegax: {
		randomBattleMoves: ["bulkup", "drainpunch", "zenheadbutt", "stoneedge", "taunt", "icebeam"],
		randomDoubleBattleMoves: ["bulkup", "drainpunch", "taunt", "stoneedge", "zenheadbutt", "icebeam"],
		tier: "Uber",
		doublesTier: "DUber",
	},
	mewtwomegay: {
		randomBattleMoves: ["psystrike", "aurasphere", "shadowball", "fireblast", "icebeam", "calmmind", "recover", "willowisp", "taunt"],
		randomDoubleBattleMoves: ["psystrike", "aurasphere", "fireblast", "icebeam", "calmmind", "willowisp", "taunt"],
		tier: "Uber",
		doublesTier: "DUber",
	},
	mew: {
		randomBattleMoves: ["defog", "roost", "willowisp", "knockoff", "taunt", "icebeam", "earthpower", "aurasphere", "stealthrock", "nastyplot", "psyshock"],
		randomDoubleBattleMoves: ["taunt", "willowisp", "transform", "roost", "psyshock", "fireblast", "icebeam", "protect", "fakeout", "helpinghand", "tailwind"],
		tier: "UU",
		doublesTier: "DOU",
	},
	chikorita: {
		tier: "LC",
	},
	bayleef: {
		tier: "NFE",
	},
	meganium: {
		randomBattleMoves: ["reflect", "lightscreen", "aromatherapy", "leechseed", "toxic", "gigadrain", "synthesis", "dragontail"],
		randomDoubleBattleMoves: ["leechseed", "leafstorm", "energyball", "dragontail", "healpulse", "toxic", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	cyndaquil: {
		tier: "LC",
	},
	quilava: {
		tier: "NFE",
	},
	typhlosion: {
		randomBattleMoves: ["eruption", "fireblast", "hiddenpowergrass", "extrasensory", "focusblast"],
		randomDoubleBattleMoves: ["eruption", "heatwave", "hiddenpowergrass", "extrasensory", "focusblast", "protect"],
		tier: "NU",
		doublesTier: "(DUU)",
	},
	totodile: {
		tier: "LC",
	},
	croconaw: {
		tier: "NFE",
	},
	feraligatr: {
		randomBattleMoves: ["aquajet", "liquidation", "crunch", "icepunch", "dragondance", "swordsdance", "earthquake"],
		randomDoubleBattleMoves: ["aquajet", "liquidation", "crunch", "icepunch", "dragondance", "protect"],
		tier: "UU",
		doublesTier: "(DUU)",
	},
	sentret: {
		tier: "LC",
	},
	furret: {
		randomBattleMoves: ["uturn", "trick", "aquatail", "firepunch", "knockoff", "doubleedge"],
		randomDoubleBattleMoves: ["uturn", "knockoff", "doubleedge", "superfang", "followme", "helpinghand", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	hoothoot: {
		tier: "LC",
	},
	noctowl: {
		randomBattleMoves: ["airslash", "defog", "heatwave", "hurricane", "hypervoice", "roost", "whirlwind"],
		randomDoubleBattleMoves: ["roost", "tailwind", "airslash", "hypervoice", "heatwave", "protect", "hypnosis"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	ledyba: {
		tier: "LC",
	},
	ledian: {
		randomBattleMoves: ["roost", "lightscreen", "encore", "reflect", "knockoff", "toxic", "uturn"],
		randomDoubleBattleMoves: ["protect", "lightscreen", "encore", "reflect", "knockoff", "bugbuzz", "uturn", "tailwind"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	spinarak: {
		tier: "LC",
	},
	ariados: {
		randomBattleMoves: ["megahorn", "toxicspikes", "poisonjab", "suckerpunch", "stickyweb"],
		randomDoubleBattleMoves: ["protect", "megahorn", "toxicthread", "poisonjab", "stickyweb", "ragepowder"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	chinchou: {
		tier: "LC",
	},
	lanturn: {
		randomBattleMoves: ["healbell", "hiddenpowergrass", "hydropump", "icebeam", "scald", "toxic", "voltswitch"],
		randomDoubleBattleMoves: ["thunderbolt", "icebeam", "thunderwave", "scald", "protect", "toxic"],
		tier: "PU",
		doublesTier: "(DUU)",
	},
	togepi: {
		tier: "LC",
	},
	togetic: {
		tier: "NFE",
	},
	togekiss: {
		randomBattleMoves: ["roost", "thunderwave", "nastyplot", "airslash", "aurasphere", "healbell", "defog"],
		randomDoubleBattleMoves: ["roost", "thunderwave", "nastyplot", "airslash", "followme", "dazzlinggleam", "tailwind", "protect"],
		tier: "UU",
		doublesTier: "DUU",
	},
	natu: {
		tier: "LC",
	},
	xatu: {
		randomBattleMoves: ["thunderwave", "toxic", "roost", "psychic", "uturn", "reflect", "calmmind", "heatwave"],
		randomDoubleBattleMoves: ["thunderwave", "tailwind", "roost", "psychic", "uturn", "heatwave", "protect"],
		tier: "NU",
		doublesTier: "(DUU)",
	},
	mareep: {
		tier: "LC",
	},
	flaaffy: {
		tier: "NFE",
	},
	ampharos: {
		randomBattleMoves: ["voltswitch", "reflect", "lightscreen", "focusblast", "thunderbolt", "toxic", "healbell", "hiddenpowerice"],
		randomDoubleBattleMoves: ["focusblast", "hiddenpowerice", "hiddenpowergrass", "thunderbolt", "protect", "thunderwave"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	ampharosmega: {
		randomBattleMoves: ["voltswitch", "focusblast", "agility", "thunderbolt", "healbell", "dragonpulse"],
		randomDoubleBattleMoves: ["focusblast", "hiddenpowerice", "hiddenpowergrass", "thunderbolt", "dragonpulse", "protect"],
		tier: "RU",
		doublesTier: "DUU",
	},
	azurill: {
		tier: "LC",
	},
	marill: {
		tier: "NFE",
	},
	azumarill: {
		randomBattleMoves: ["liquidation", "aquajet", "playrough", "superpower", "bellydrum", "knockoff"],
		randomDoubleBattleMoves: ["liquidation", "aquajet", "playrough", "superpower", "knockoff", "protect"],
		tier: "OU",
		doublesTier: "DUU",
	},
	bonsly: {
		tier: "LC",
	},
	sudowoodo: {
		randomBattleMoves: ["headsmash", "earthquake", "suckerpunch", "woodhammer", "toxic", "stealthrock"],
		randomDoubleBattleMoves: ["headsmash", "stompingtantrum", "suckerpunch", "woodhammer", "stealthrock", "helpinghand", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	hoppip: {
		tier: "LC",
	},
	skiploom: {
		tier: "NFE",
	},
	jumpluff: {
		randomBattleMoves: ["swordsdance", "sleeppowder", "uturn", "encore", "toxic", "acrobatics", "leechseed", "seedbomb", "substitute", "strengthsap"],
		randomDoubleBattleMoves: ["encore", "sleeppowder", "uturn", "helpinghand", "leechseed", "energyball", "ragepowder", "protect", "strengthsap"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	aipom: {
		tier: "LC Uber",
	},
	ambipom: {
		randomBattleMoves: ["fakeout", "return", "knockoff", "uturn", "switcheroo", "seedbomb", "lowkick"],
		randomDoubleBattleMoves: ["fakeout", "return", "knockoff", "uturn", "icepunch", "lowkick", "protect"],
		tier: "NU",
		doublesTier: "(DUU)",
	},
	sunkern: {
		tier: "LC",
	},
	sunflora: {
		randomBattleMoves: ["sunnyday", "gigadrain", "solarbeam", "hiddenpowerfire", "earthpower"],
		randomDoubleBattleMoves: ["sunnyday", "energyball", "solarbeam", "hiddenpowerfire", "earthpower", "protect", "helpinghand", "encore"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	yanma: {
		tier: "LC Uber",
	},
	yanmega: {
		randomBattleMoves: ["bugbuzz", "airslash", "uturn", "protect", "gigadrain"],
		tier: "RU",
		doublesTier: "(DUU)",
	},
	wooper: {
		tier: "LC",
	},
	quagsire: {
		randomBattleMoves: ["recover", "earthquake", "scald", "toxic", "encore", "icebeam"],
		randomDoubleBattleMoves: ["icywind", "earthquake", "scald", "recover", "toxic", "protect"],
		tier: "UU",
		doublesTier: "(DUU)",
	},
	murkrow: {
		tier: "LC Uber",
	},
	honchkrow: {
		randomBattleMoves: ["superpower", "suckerpunch", "bravebird", "roost", "heatwave", "pursuit"],
		randomDoubleBattleMoves: ["superpower", "suckerpunch", "bravebird", "roost", "heatwave", "protect"],
		tier: "RU",
		doublesTier: "(DUU)",
	},
	misdreavus: {
		tier: "LC Uber",
	},
	mismagius: {
		randomBattleMoves: ["nastyplot", "substitute", "willowisp", "shadowball", "thunderbolt", "dazzlinggleam", "taunt", "painsplit", "destinybond"],
		randomDoubleBattleMoves: ["nastyplot", "willowisp", "shadowball", "thunderbolt", "dazzlinggleam", "taunt", "protect"],
		tier: "NU",
		doublesTier: "(DUU)",
	},
	unown: {
		randomBattleMoves: ["hiddenpowerpsychic"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	wynaut: {
		tier: "LC",
	},
	wobbuffet: {
		randomBattleMoves: ["counter", "destinybond", "encore", "mirrorcoat"],
		randomDoubleBattleMoves: ["counter", "mirrorcoat", "encore", "charm"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	girafarig: {
		randomBattleMoves: ["psychic", "psyshock", "thunderbolt", "nastyplot", "substitute", "hypervoice"],
		randomDoubleBattleMoves: ["psychic", "psyshock", "thunderbolt", "nastyplot", "protect", "hypervoice"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	pineco: {
		tier: "LC",
	},
	forretress: {
		randomBattleMoves: ["rapidspin", "toxic", "spikes", "voltswitch", "stealthrock", "gyroball"],
		randomDoubleBattleMoves: ["toxic", "voltswitch", "stealthrock", "gyroball", "protect"],
		tier: "RU",
		doublesTier: "(DUU)",
	},
	dunsparce: {
		randomBattleMoves: ["bodyslam", "rockslide", "bite", "coil", "glare", "headbutt", "roost"],
		randomDoubleBattleMoves: ["coil", "rockslide", "bite", "headbutt", "glare", "bodyslam", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	gligar: {
		randomBattleMoves: ["stealthrock", "toxic", "roost", "defog", "earthquake", "uturn", "knockoff"],
		tier: "UU",
		doublesTier: "LC Uber",
	},
	gliscor: {
		randomBattleMoves: ["roost", "taunt", "earthquake", "protect", "toxic", "stealthrock", "knockoff", "uturn"],
		randomDoubleBattleMoves: ["tailwind", "taunt", "earthquake", "protect", "facade", "knockoff"],
		tier: "OU",
		doublesTier: "(DUU)",
	},
	snubbull: {
		tier: "LC",
	},
	granbull: {
		randomBattleMoves: ["thunderwave", "playrough", "crunch", "earthquake", "healbell"],
		randomDoubleBattleMoves: ["thunderwave", "playrough", "stompingtantrum", "snarl", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	qwilfish: {
		randomBattleMoves: ["toxicspikes", "liquidation", "spikes", "painsplit", "thunderwave", "taunt", "destinybond"],
		randomDoubleBattleMoves: ["poisonjab", "liquidation", "swordsdance", "protect", "thunderwave", "taunt", "destinybond"],
		tier: "PU",
		doublesTier: "(DUU)",
	},
	shuckle: {
		randomBattleMoves: ["toxic", "encore", "stealthrock", "knockoff", "stickyweb", "infestation"],
		randomDoubleBattleMoves: ["encore", "stealthrock", "knockoff", "stickyweb", "guardsplit", "toxic", "helpinghand"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	heracross: {
		randomBattleMoves: ["closecombat", "facade", "knockoff", "megahorn", "stoneedge", "swordsdance"],
		randomDoubleBattleMoves: ["closecombat", "megahorn", "facade", "swordsdance", "knockoff", "protect"],
		tier: "RUBL",
		doublesTier: "(DUU)",
	},
	heracrossmega: {
		randomBattleMoves: ["closecombat", "pinmissile", "rockblast", "substitute", "swordsdance"],
		randomDoubleBattleMoves: ["closecombat", "pinmissile", "rockblast", "swordsdance", "bulletseed", "knockoff", "protect"],
		tier: "UUBL",
		doublesTier: "(DUU)",
	},
	sneasel: {
		tier: "NU",
		doublesTier: "LC Uber",
	},
	weavile: {
		randomBattleMoves: ["iceshard", "iciclecrash", "knockoff", "pursuit", "swordsdance", "lowkick"],
		randomDoubleBattleMoves: ["iceshard", "iciclecrash", "knockoff", "fakeout", "swordsdance", "lowkick", "protect"],
		tier: "UUBL",
		doublesTier: "DUU",
	},
	teddiursa: {
		tier: "LC",
	},
	ursaring: {
		randomBattleMoves: ["swordsdance", "facade", "closecombat", "crunch", "protect"],
		randomDoubleBattleMoves: ["swordsdance", "facade", "closecombat", "crunch", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	slugma: {
		tier: "LC",
	},
	magcargo: {
		randomBattleMoves: ["recover", "lavaplume", "toxic", "hiddenpowergrass", "stealthrock", "fireblast", "earthpower", "shellsmash", "ancientpower"],
		randomDoubleBattleMoves: ["protect", "heatwave", "willowisp", "stealthrock", "fireblast", "incinerate", "earthpower"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	swinub: {
		tier: "LC",
	},
	piloswine: {
		tier: "NU",
		doublesTier: "NFE",
	},
	mamoswine: {
		randomBattleMoves: ["iceshard", "earthquake", "endeavor", "iciclecrash", "stealthrock", "superpower", "knockoff"],
		randomDoubleBattleMoves: ["iceshard", "earthquake", "rockslide", "iciclecrash", "protect", "superpower", "knockoff"],
		tier: "UU",
		doublesTier: "DUU",
	},
	corsola: {
		randomBattleMoves: ["recover", "toxic", "powergem", "scald", "stealthrock"],
		randomDoubleBattleMoves: ["protect", "icywind", "powergem", "scald", "stealthrock", "toxic"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	remoraid: {
		tier: "LC",
	},
	octillery: {
		randomBattleMoves: ["hydropump", "fireblast", "icebeam", "energyball", "rockblast", "gunkshot", "scald"],
		randomDoubleBattleMoves: ["hydropump", "fireblast", "icebeam", "energyball", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	delibird: {
		randomBattleMoves: ["spikes", "rapidspin", "icywind", "freezedry", "destinybond"],
		randomDoubleBattleMoves: ["fakeout", "iceshard", "icepunch", "aerialace", "brickbreak", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	mantyke: {
		tier: "LC",
	},
	mantine: {
		randomBattleMoves: ["scald", "airslash", "roost", "toxic", "defog"],
		randomDoubleBattleMoves: ["scald", "tailwind", "wideguard", "helpinghand", "protect", "defog", "toxic"],
		tier: "RU",
		doublesTier: "(DUU)",
	},
	skarmory: {
		randomBattleMoves: ["bravebird", "roost", "spikes", "stealthrock", "whirlwind"],
		randomDoubleBattleMoves: ["skydrop", "bravebird", "tailwind", "taunt", "feint", "protect", "ironhead", "stealthrock"],
		tier: "OU",
		doublesTier: "(DUU)",
	},
	houndour: {
		tier: "LC",
	},
	houndoom: {
		randomBattleMoves: ["nastyplot", "darkpulse", "suckerpunch", "fireblast", "hiddenpowergrass"],
		randomDoubleBattleMoves: ["nastyplot", "darkpulse", "suckerpunch", "heatwave", "protect"],
		tier: "PUBL",
		doublesTier: "(DUU)",
	},
	houndoommega: {
		randomBattleMoves: ["nastyplot", "darkpulse", "taunt", "fireblast", "hiddenpowergrass"],
		randomDoubleBattleMoves: ["nastyplot", "darkpulse", "taunt", "heatwave", "hiddenpowergrass", "protect"],
		tier: "RUBL",
		doublesTier: "(DUU)",
	},
	phanpy: {
		tier: "LC",
	},
	donphan: {
		randomBattleMoves: ["stealthrock", "rapidspin", "iceshard", "earthquake", "knockoff", "stoneedge"],
		randomDoubleBattleMoves: ["stealthrock", "knockoff", "iceshard", "earthquake", "rockslide", "protect", "rapidspin"],
		tier: "RU",
		doublesTier: "(DUU)",
	},
	stantler: {
		randomBattleMoves: ["doubleedge", "megahorn", "jumpkick", "earthquake", "suckerpunch"],
		randomDoubleBattleMoves: ["return", "megahorn", "jumpkick", "earthquake", "suckerpunch", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	smeargle: {
		randomBattleMoves: ["spore", "stealthrock", "destinybond", "whirlwind", "stickyweb"],
		randomDoubleBattleMoves: ["spore", "fakeout", "wideguard", "helpinghand", "followme", "tailwind", "kingsshield", "transform", "stickyweb"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	miltank: {
		randomBattleMoves: ["milkdrink", "stealthrock", "bodyslam", "healbell", "curse", "earthquake", "toxic"],
		randomDoubleBattleMoves: ["protect", "helpinghand", "bodyslam", "milkdrink", "curse", "stompingtantrum", "thunderwave"],
		tier: "NU",
		doublesTier: "(DUU)",
	},
	raikou: {
		randomBattleMoves: ["thunderbolt", "hiddenpowerice", "aurasphere", "calmmind", "substitute", "voltswitch", "extrasensory"],
		randomDoubleBattleMoves: ["thunderbolt", "hiddenpowerice", "calmmind", "snarl", "protect"],
		tier: "RU",
		doublesTier: "(DUU)",
	},
	entei: {
		randomBattleMoves: ["extremespeed", "flareblitz", "stompingtantrum", "stoneedge", "sacredfire"],
		randomDoubleBattleMoves: ["extremespeed", "flareblitz", "stoneedge", "sacredfire", "protect", "stompingtantrum"],
		tier: "RUBL",
		doublesTier: "DUU",
	},
	suicune: {
		randomBattleMoves: ["hydropump", "icebeam", "scald", "hiddenpowergrass", "rest", "sleeptalk", "calmmind"],
		randomDoubleBattleMoves: ["icebeam", "scald", "snarl", "tailwind", "toxic"],
		tier: "UU",
		doublesTier: "DOU",
	},
	larvitar: {
		tier: "LC",
	},
	pupitar: {
		tier: "NFE",
	},
	tyranitar: {
		randomBattleMoves: ["crunch", "stoneedge", "pursuit", "earthquake", "fireblast", "icebeam", "stealthrock"],
		randomDoubleBattleMoves: ["crunch", "stoneedge", "rockslide", "stompingtantrum", "fireblast", "icebeam", "stealthrock", "protect"],
		tier: "OU",
		doublesTier: "DOU",
	},
	tyranitarmega: {
		randomBattleMoves: ["crunch", "stoneedge", "earthquake", "icepunch", "dragondance"],
		randomDoubleBattleMoves: ["crunch", "stoneedge", "earthquake", "icepunch", "dragondance", "rockslide", "protect"],
		tier: "OU",
		doublesTier: "DOU",
	},
	lugia: {
		randomBattleMoves: ["toxic", "roost", "substitute", "whirlwind", "aeroblast", "earthquake"],
		randomDoubleBattleMoves: ["aeroblast", "roost", "tailwind", "psychic", "skydrop", "protect", "toxic"],
		tier: "Uber",
		doublesTier: "DUber",
	},
	hooh: {
		randomBattleMoves: ["bravebird", "defog", "earthquake", "roost", "sacredfire", "substitute", "toxic"],
		randomDoubleBattleMoves: ["sacredfire", "bravebird", "earthpower", "roost", "toxic", "tailwind", "skydrop", "protect"],
		tier: "Uber",
		doublesTier: "DUber",
	},
	celebi: {
		randomBattleMoves: ["nastyplot", "psychic", "gigadrain", "recover", "earthpower", "hiddenpowerfire", "leafstorm", "uturn", "thunderwave"],
		randomDoubleBattleMoves: ["protect", "psychic", "energyball", "recover", "earthpower", "nastyplot", "uturn", "thunderwave"],
		tier: "UU",
		doublesTier: "(DUU)",
	},
	treecko: {
		tier: "LC",
	},
	grovyle: {
		tier: "NFE",
	},
	sceptile: {
		randomBattleMoves: ["gigadrain", "leafstorm", "hiddenpowerice", "focusblast", "hiddenpowerflying"],
		randomDoubleBattleMoves: ["energyball", "hiddenpowerice", "focusblast", "hiddenpowerfire", "protect"],
		tier: "NU",
		doublesTier: "(DUU)",
	},
	sceptilemega: {
		randomBattleMoves: ["substitute", "gigadrain", "dragonpulse", "focusblast", "swordsdance", "outrage", "leafblade", "earthquake", "hiddenpowerfire"],
		randomDoubleBattleMoves: ["energyball", "leafstorm", "hiddenpowerice", "focusblast", "dragonpulse", "hiddenpowerfire", "protect"],
		tier: "RU",
		doublesTier: "DUU",
	},
	torchic: {
		tier: "LC",
	},
	combusken: {
		tier: "NFE",
	},
	blaziken: {
		randomBattleMoves: ["fireblast", "highjumpkick", "protect", "knockoff", "hiddenpowerice"],
		tier: "Uber",
		doublesTier: "(DUU)",
	},
	blazikenmega: {
		randomBattleMoves: ["flareblitz", "highjumpkick", "protect", "swordsdance", "stoneedge", "knockoff"],
		tier: "Uber",
		doublesTier: "DUU",
	},
	mudkip: {
		tier: "LC",
	},
	marshtomp: {
		tier: "NFE",
	},
	swampert: {
		randomBattleMoves: ["stealthrock", "earthquake", "scald", "icebeam", "roar", "toxic", "protect"],
		randomDoubleBattleMoves: ["earthquake", "stealthrock", "wideguard", "scald", "muddywater", "protect", "icywind"],
		tier: "UU",
		doublesTier: "(DUU)",
	},
	swampertmega: {
		randomBattleMoves: ["raindance", "waterfall", "earthquake", "icepunch", "superpower"],
		randomDoubleBattleMoves: ["waterfall", "earthquake", "raindance", "icepunch", "protect"],
		tier: "OU",
		doublesTier: "DOU",
	},
	poochyena: {
		tier: "LC",
	},
	mightyena: {
		randomBattleMoves: ["crunch", "suckerpunch", "playrough", "firefang", "irontail"],
		randomDoubleBattleMoves: ["suckerpunch", "crunch", "playrough", "firefang", "taunt", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	zigzagoon: {
		tier: "LC",
	},
	linoone: {
		randomBattleMoves: ["bellydrum", "extremespeed", "stompingtantrum", "shadowclaw"],
		randomDoubleBattleMoves: ["bellydrum", "extremespeed", "stompingtantrum", "protect", "shadowclaw"],
		tier: "RUBL",
		doublesTier: "(DUU)",
	},
	wurmple: {
		tier: "LC",
	},
	silcoon: {
		tier: "NFE",
	},
	beautifly: {
		randomBattleMoves: ["quiverdance", "bugbuzz", "psychic", "energyball", "hiddenpowerfighting"],
		randomDoubleBattleMoves: ["quiverdance", "bugbuzz", "aircutter", "tailwind", "stringshot", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	cascoon: {
		tier: "NFE",
	},
	dustox: {
		randomBattleMoves: ["roost", "defog", "bugbuzz", "sludgebomb", "quiverdance", "uturn"],
		randomDoubleBattleMoves: ["tailwind", "stringshot", "strugglebug", "bugbuzz", "protect", "sludgebomb"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	lotad: {
		tier: "LC",
	},
	lombre: {
		tier: "NFE",
	},
	ludicolo: {
		randomBattleMoves: ["raindance", "hydropump", "scald", "gigadrain", "icebeam", "focusblast"],
		randomDoubleBattleMoves: ["raindance", "hydropump", "gigadrain", "icebeam", "fakeout", "protect"],
		tier: "PU",
		doublesTier: "(DUU)",
	},
	seedot: {
		tier: "LC",
	},
	nuzleaf: {
		tier: "NFE",
	},
	shiftry: {
		randomBattleMoves: ["defog", "knockoff", "leafstorm", "lowkick", "seedbomb", "suckerpunch", "swordsdance"],
		randomDoubleBattleMoves: ["leafstorm", "swordsdance", "leafblade", "suckerpunch", "knockoff", "fakeout", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	taillow: {
		tier: "LC",
	},
	swellow: {
		randomBattleMoves: ["protect", "facade", "bravebird", "uturn", "quickattack"],
		randomDoubleBattleMoves: ["bravebird", "facade", "quickattack", "uturn", "protect"],
		tier: "RU",
		doublesTier: "(DUU)",
	},
	wingull: {
		tier: "LC Uber",
	},
	pelipper: {
		randomBattleMoves: ["scald", "hurricane", "hydropump", "uturn", "roost", "defog", "knockoff"],
		randomDoubleBattleMoves: ["scald", "hurricane", "wideguard", "protect", "tailwind", "uturn"],
		tier: "OU",
		doublesTier: "DOU",
	},
	ralts: {
		tier: "LC",
	},
	kirlia: {
		tier: "NFE",
	},
	gardevoir: {
		randomBattleMoves: ["psychic", "thunderbolt", "focusblast", "shadowball", "moonblast", "calmmind", "substitute", "willowisp"],
		randomDoubleBattleMoves: ["psyshock", "focusblast", "moonblast", "helpinghand", "protect", "dazzlinggleam"],
		tier: "RU",
		doublesTier: "DUU",
	},
	gardevoirmega: {
		randomBattleMoves: ["calmmind", "hypervoice", "psyshock", "focusblast", "substitute", "taunt", "willowisp"],
		randomDoubleBattleMoves: ["psyshock", "focusblast", "calmmind", "hypervoice", "protect"],
		tier: "UUBL",
		doublesTier: "DOU",
	},
	gallade: {
		randomBattleMoves: ["bulkup", "closecombat", "drainpunch", "icepunch", "knockoff", "shadowsneak", "substitute", "zenheadbutt"],
		randomDoubleBattleMoves: ["closecombat", "trick", "shadowsneak", "icepunch", "zenheadbutt", "knockoff", "protect", "helpinghand"],
		tier: "PUBL",
		doublesTier: "(DUU)",
	},
	gallademega: {
		randomBattleMoves: ["closecombat", "icepunch", "knockoff", "swordsdance", "zenheadbutt"],
		randomDoubleBattleMoves: ["closecombat", "drainpunch", "icepunch", "zenheadbutt", "swordsdance", "knockoff", "protect"],
		tier: "UUBL",
		doublesTier: "(DUU)",
	},
	surskit: {
		tier: "LC",
	},
	masquerain: {
		randomBattleMoves: ["quiverdance", "bugbuzz", "airslash", "hydropump", "stickyweb"],
		randomDoubleBattleMoves: ["hydropump", "bugbuzz", "airslash", "quiverdance", "tailwind", "stickyweb", "strugglebug", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	shroomish: {
		tier: "LC",
	},
	breloom: {
		randomBattleMoves: ["spore", "machpunch", "bulletseed", "rocktomb", "swordsdance"],
		randomDoubleBattleMoves: ["spore", "machpunch", "bulletseed", "rocktomb", "protect"],
		tier: "UUBL",
		doublesTier: "DUU",
	},
	slakoth: {
		tier: "LC",
	},
	vigoroth: {
		tier: "NFE",
	},
	slaking: {
		randomBattleMoves: ["earthquake", "pursuit", "nightslash", "retaliate", "gigaimpact", "firepunch"],
		randomDoubleBattleMoves: ["earthquake", "nightslash", "doubleedge", "retaliate", "hammerarm", "rockslide"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	nincada: {
		tier: "LC",
	},
	ninjask: {
		randomBattleMoves: ["swordsdance", "aerialace", "nightslash", "dig", "leechlife", "uturn"],
		randomDoubleBattleMoves: ["swordsdance", "protect", "leechlife", "aerialace", "dig"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	shedinja: {
		randomBattleMoves: ["swordsdance", "willowisp", "xscissor", "shadowsneak", "shadowclaw"],
		randomDoubleBattleMoves: ["swordsdance", "willowisp", "xscissor", "shadowsneak", "allyswitch", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	whismur: {
		tier: "LC",
	},
	loudred: {
		tier: "NFE",
	},
	exploud: {
		randomBattleMoves: ["boomburst", "fireblast", "icebeam", "surf", "focusblast"],
		randomDoubleBattleMoves: ["boomburst", "fireblast", "icebeam", "focusblast", "protect", "hypervoice"],
		tier: "NUBL",
		doublesTier: "(DUU)",
	},
	makuhita: {
		tier: "LC",
	},
	hariyama: {
		randomBattleMoves: ["bulletpunch", "closecombat", "icepunch", "stoneedge", "bulkup", "knockoff"],
		randomDoubleBattleMoves: ["bulletpunch", "closecombat", "facade", "fakeout", "knockoff", "helpinghand", "wideguard", "protect"],
		tier: "NU",
		doublesTier: "DUU",
	},
	nosepass: {
		tier: "LC",
	},
	probopass: {
		randomBattleMoves: ["stealthrock", "thunderwave", "toxic", "flashcannon", "voltswitch", "earthpower"],
		randomDoubleBattleMoves: ["stealthrock", "thunderwave", "helpinghand", "powergem", "wideguard", "protect", "flashcannon"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	skitty: {
		tier: "LC",
	},
	delcatty: {
		randomBattleMoves: ["doubleedge", "suckerpunch", "wildcharge", "fakeout", "thunderwave", "healbell"],
		randomDoubleBattleMoves: ["doubleedge", "suckerpunch", "fakeout", "thunderwave", "protect", "helpinghand"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	sableye: {
		randomBattleMoves: ["foulplay", "recover", "taunt", "toxic", "willowisp"],
		randomDoubleBattleMoves: ["recover", "willowisp", "taunt", "fakeout", "foulplay", "helpinghand", "snarl", "protect"],
		tier: "PU",
		doublesTier: "DUU",
	},
	sableyemega: {
		randomBattleMoves: ["calmmind", "darkpulse", "recover", "shadowball", "willowisp"],
		randomDoubleBattleMoves: ["recover", "fakeout", "knockoff", "shadowball", "willowisp", "protect"],
		tier: "OU",
		doublesTier: "DUU",
	},
	mawile: {
		randomBattleMoves: ["swordsdance", "ironhead", "stealthrock", "playrough", "suckerpunch", "knockoff"],
		randomDoubleBattleMoves: ["swordsdance", "ironhead", "playrough", "suckerpunch", "knockoff", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	mawilemega: {
		randomBattleMoves: ["swordsdance", "ironhead", "firefang", "substitute", "playrough", "suckerpunch", "knockoff", "focuspunch"],
		randomDoubleBattleMoves: ["swordsdance", "ironhead", "playrough", "suckerpunch", "knockoff", "protect"],
		tier: "OU",
		doublesTier: "DUU",
	},
	aron: {
		tier: "LC",
	},
	lairon: {
		tier: "NFE",
	},
	aggron: {
		randomBattleMoves: ["autotomize", "headsmash", "earthquake", "lowkick", "heavyslam", "aquatail", "stealthrock"],
		randomDoubleBattleMoves: ["headsmash", "stompingtantrum", "heavyslam", "stealthrock", "protect"],
		tier: "PU",
		doublesTier: "(DUU)",
	},
	aggronmega: {
		randomBattleMoves: ["earthquake", "heavyslam", "rockslide", "stealthrock", "thunderwave", "roar", "toxic"],
		randomDoubleBattleMoves: ["rockslide", "stompingtantrum", "heavyslam", "toxic", "protect", "stealthrock"],
		tier: "UU",
		doublesTier: "(DUU)",
	},
	meditite: {
		tier: "LC Uber",
	},
	medicham: {
		randomBattleMoves: ["highjumpkick", "drainpunch", "zenheadbutt", "icepunch", "bulletpunch"],
		randomDoubleBattleMoves: ["highjumpkick", "drainpunch", "zenheadbutt", "icepunch", "bulletpunch", "protect", "fakeout"],
		tier: "NU",
		doublesTier: "(DUU)",
	},
	medichammega: {
		randomBattleMoves: ["highjumpkick", "zenheadbutt", "thunderpunch", "icepunch", "fakeout"],
		randomDoubleBattleMoves: ["highjumpkick", "drainpunch", "zenheadbutt", "icepunch", "bulletpunch", "protect", "fakeout"],
		tier: "OU",
		doublesTier: "(DUU)",
	},
	electrike: {
		tier: "LC",
	},
	manectric: {
		randomBattleMoves: ["voltswitch", "thunderbolt", "hiddenpowerice", "hiddenpowergrass", "overheat", "flamethrower"],
		randomDoubleBattleMoves: ["voltswitch", "thunderbolt", "hiddenpowerice", "hiddenpowergrass", "flamethrower", "snarl", "protect", "switcheroo"],
		tier: "PU",
		doublesTier: "(DUU)",
	},
	manectricmega: {
		randomBattleMoves: ["voltswitch", "thunderbolt", "hiddenpowerice", "hiddenpowergrass", "overheat"],
		randomDoubleBattleMoves: ["voltswitch", "thunderbolt", "hiddenpowerice", "hiddenpowergrass", "flamethrower", "snarl", "protect"],
		tier: "UU",
		doublesTier: "DOU",
	},
	plusle: {
		randomBattleMoves: ["nastyplot", "thunderbolt", "substitute", "hiddenpowerice", "encore"],
		randomDoubleBattleMoves: ["nastyplot", "thunderbolt", "protect", "hiddenpowerice", "encore", "helpinghand"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	minun: {
		randomBattleMoves: ["nastyplot", "thunderbolt", "substitute", "hiddenpowerice", "encore"],
		randomDoubleBattleMoves: ["nastyplot", "thunderbolt", "protect", "hiddenpowerice", "encore", "helpinghand"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	volbeat: {
		randomBattleMoves: ["uturn", "roost", "thunderwave", "encore", "tailwind", "defog"],
		randomDoubleBattleMoves: ["stringshot", "strugglebug", "helpinghand", "thunderwave", "encore", "tailwind", "protect", "uturn"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	illumise: {
		randomBattleMoves: ["uturn", "roost", "bugbuzz", "thunderwave", "encore", "wish", "defog"],
		randomDoubleBattleMoves: ["protect", "helpinghand", "bugbuzz", "encore", "thunderwave", "tailwind"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	budew: {
		tier: "LC",
	},
	roselia: {
		tier: "PU",
		doublesTier: "NFE",
	},
	roserade: {
		randomBattleMoves: ["sludgebomb", "gigadrain", "sleeppowder", "leafstorm", "spikes", "toxicspikes", "synthesis", "hiddenpowerfire"],
		randomDoubleBattleMoves: ["sludgebomb", "gigadrain", "sleeppowder", "leafstorm", "protect", "hiddenpowerfire"],
		tier: "RU",
		doublesTier: "(DUU)",
	},
	gulpin: {
		tier: "LC",
	},
	swalot: {
		randomBattleMoves: ["sludgebomb", "icebeam", "toxic", "yawn", "encore", "painsplit", "earthquake"],
		randomDoubleBattleMoves: ["sludgebomb", "icebeam", "protect", "yawn", "encore", "poisongas"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	carvanha: {
		tier: "LC",
	},
	sharpedo: {
		randomBattleMoves: ["protect", "icebeam", "crunch", "earthquake", "waterfall"],
		randomDoubleBattleMoves: ["protect", "icebeam", "crunch", "liquidation", "psychicfangs"],
		tier: "RUBL",
		doublesTier: "(DUU)",
	},
	sharpedomega: {
		randomBattleMoves: ["protect", "crunch", "waterfall", "icefang", "psychicfangs", "destinybond"],
		randomDoubleBattleMoves: ["protect", "icefang", "crunch", "liquidation", "psychicfangs"],
		tier: "UU",
		doublesTier: "(DUU)",
	},
	wailmer: {
		tier: "LC",
	},
	wailord: {
		randomBattleMoves: ["waterspout", "hydropump", "icebeam", "hiddenpowergrass", "hiddenpowerfire"],
		randomDoubleBattleMoves: ["waterspout", "hydropump", "icebeam", "hiddenpowergrass", "hiddenpowerfire"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	numel: {
		tier: "LC",
	},
	camerupt: {
		randomBattleMoves: ["rockpolish", "fireblast", "earthpower", "lavaplume", "stealthrock", "hiddenpowergrass", "roar", "stoneedge"],
		randomDoubleBattleMoves: ["fireblast", "earthpower", "heatwave", "incinerate", "protect", "stealthrock"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	cameruptmega: {
		randomBattleMoves: ["stealthrock", "fireblast", "earthpower", "ancientpower", "willowisp", "toxic"],
		randomDoubleBattleMoves: ["fireblast", "earthpower", "heatwave", "rockslide", "protect"],
		tier: "NUBL",
		doublesTier: "DOU",
	},
	torkoal: {
		randomBattleMoves: ["shellsmash", "fireblast", "earthpower", "solarbeam", "stealthrock", "rapidspin", "yawn", "lavaplume"],
		randomDoubleBattleMoves: ["protect", "heatwave", "earthpower", "willowisp", "fireblast", "solarbeam"],
		tier: "(PU)",
		doublesTier: "DUU",
	},
	spoink: {
		tier: "LC",
	},
	grumpig: {
		randomBattleMoves: ["psychic", "thunderwave", "healbell", "whirlwind", "toxic", "focusblast", "reflect", "lightscreen"],
		randomDoubleBattleMoves: ["psychic", "thunderwave", "taunt", "protect", "focusblast", "reflect", "lightscreen"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	spinda: {
		randomBattleMoves: ["return", "superpower", "rockslide", "encore"],
		randomDoubleBattleMoves: ["return", "superpower", "suckerpunch", "trickroom", "fakeout", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	trapinch: {
		tier: "LC Uber",
	},
	vibrava: {
		tier: "NFE",
	},
	flygon: {
		randomBattleMoves: ["earthquake", "outrage", "uturn", "roost", "defog", "firepunch", "dragondance"],
		randomDoubleBattleMoves: ["earthquake", "protect", "dragonclaw", "uturn", "fireblast", "tailwind", "dragondance"],
		tier: "RU",
		doublesTier: "(DUU)",
	},
	cacnea: {
		tier: "LC",
	},
	cacturne: {
		randomBattleMoves: ["swordsdance", "spikes", "suckerpunch", "seedbomb", "drainpunch", "substitute", "darkpulse", "focusblast", "gigadrain"],
		randomDoubleBattleMoves: ["swordsdance", "spikyshield", "suckerpunch", "seedbomb", "drainpunch", "substitute"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	swablu: {
		tier: "LC",
	},
	altaria: {
		randomBattleMoves: ["dracometeor", "fireblast", "earthquake", "roost", "toxic", "defog"],
		randomDoubleBattleMoves: ["dracometeor", "protect", "dragonclaw", "fireblast", "tailwind"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	altariamega: {
		randomBattleMoves: ["dragondance", "return", "hypervoice", "healbell", "earthquake", "roost", "fireblast"],
		randomDoubleBattleMoves: ["dragondance", "return", "doubleedge", "earthquake", "protect", "fireblast"],
		tier: "UU",
		doublesTier: "(DUU)",
	},
	zangoose: {
		randomBattleMoves: ["swordsdance", "closecombat", "knockoff", "quickattack", "facade"],
		randomDoubleBattleMoves: ["protect", "closecombat", "knockoff", "quickattack", "facade"],
		tier: "PU",
		doublesTier: "(DUU)",
	},
	seviper: {
		randomBattleMoves: ["flamethrower", "sludgewave", "gigadrain", "darkpulse", "switcheroo", "swordsdance", "earthquake", "poisonjab", "suckerpunch"],
		randomDoubleBattleMoves: ["flamethrower", "gigadrain", "earthquake", "suckerpunch", "aquatail", "protect", "glare", "poisonjab", "sludgebomb"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	lunatone: {
		randomBattleMoves: ["earthpower", "icebeam", "moonlight", "powergem", "psychic", "rockpolish", "stealthrock", "toxic"],
		randomDoubleBattleMoves: ["psychic", "earthpower", "helpinghand", "powergem", "protect", "trickroom"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	solrock: {
		randomBattleMoves: ["earthquake", "explosion", "morningsun", "rockslide", "stealthrock", "willowisp"],
		randomDoubleBattleMoves: ["protect", "helpinghand", "stoneedge", "zenheadbutt", "willowisp", "stealthrock", "rockslide"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	barboach: {
		tier: "LC",
	},
	whiscash: {
		randomBattleMoves: ["dragondance", "waterfall", "earthquake", "stoneedge", "zenheadbutt"],
		randomDoubleBattleMoves: ["dragondance", "waterfall", "earthquake", "stoneedge", "zenheadbutt", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	corphish: {
		tier: "LC",
	},
	crawdaunt: {
		randomBattleMoves: ["dragondance", "crabhammer", "superpower", "swordsdance", "knockoff", "aquajet"],
		randomDoubleBattleMoves: ["dragondance", "crabhammer", "superpower", "swordsdance", "knockoff", "aquajet", "protect"],
		tier: "UU",
		doublesTier: "DUU",
	},
	baltoy: {
		tier: "LC",
	},
	claydol: {
		randomBattleMoves: ["stealthrock", "toxic", "psychic", "icebeam", "earthquake", "rapidspin"],
		randomDoubleBattleMoves: ["allyswitch", "earthpower", "stealthrock", "rapidspin", "toxic", "protect"],
		tier: "PU",
		doublesTier: "(DUU)",
	},
	lileep: {
		tier: "LC",
	},
	cradily: {
		randomBattleMoves: ["stealthrock", "recover", "gigadrain", "toxic", "seedbomb", "rockslide", "curse"],
		randomDoubleBattleMoves: ["protect", "recover", "gigadrain", "rockslide", "stealthrock", "toxic", "stringshot"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	anorith: {
		tier: "LC",
	},
	armaldo: {
		randomBattleMoves: ["stealthrock", "stoneedge", "toxic", "xscissor", "knockoff", "rapidspin", "earthquake"],
		randomDoubleBattleMoves: ["rockslide", "stoneedge", "stringshot", "xscissor", "swordsdance", "knockoff", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	feebas: {
		tier: "LC",
	},
	milotic: {
		randomBattleMoves: ["recover", "scald", "toxic", "icebeam", "dragontail", "rest", "sleeptalk"],
		randomDoubleBattleMoves: ["hypnosis", "scald", "icywind", "recover", "protect"],
		tier: "RU",
		doublesTier: "DOU",
	},
	castform: {
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	castformsunny: {
		randomBattleMoves: ["sunnyday", "fireblast", "solarbeam", "icebeam"],
	},
	castformrainy: {
		randomBattleMoves: ["raindance", "hydropump", "thunder", "hurricane"],
	},
	castformsnowy: {
		randomBattleMoves: ["hail", "blizzard", "thunderbolt", "fireblast"],
	},
	kecleon: {
		randomBattleMoves: ["fakeout", "knockoff", "drainpunch", "suckerpunch", "shadowsneak", "stealthrock", "recover"],
		randomDoubleBattleMoves: ["knockoff", "fakeout", "trickroom", "drainpunch", "shadowsneak", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	shuppet: {
		tier: "LC",
	},
	banette: {
		randomBattleMoves: ["destinybond", "taunt", "shadowclaw", "suckerpunch", "willowisp", "shadowsneak", "knockoff"],
		randomDoubleBattleMoves: ["shadowclaw", "willowisp", "shadowsneak", "knockoff", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	banettemega: {
		randomBattleMoves: ["destinybond", "taunt", "shadowclaw", "suckerpunch", "willowisp", "knockoff"],
		randomDoubleBattleMoves: ["destinybond", "taunt", "shadowclaw", "suckerpunch", "willowisp", "knockoff", "protect"],
		tier: "RU",
		doublesTier: "(DUU)",
	},
	duskull: {
		tier: "LC",
	},
	dusclops: {
		tier: "NFE",
	},
	dusknoir: {
		randomBattleMoves: ["willowisp", "shadowsneak", "icepunch", "painsplit", "substitute", "earthquake", "focuspunch"],
		randomDoubleBattleMoves: ["allyswitch", "willowisp", "shadowsneak", "icepunch", "painsplit", "protect", "helpinghand", "trickroom"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	tropius: {
		randomBattleMoves: ["leechseed", "substitute", "airslash", "gigadrain", "toxic", "protect"],
		randomDoubleBattleMoves: ["leechseed", "protect", "airslash", "gigadrain", "tailwind", "roost"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	chingling: {
		tier: "LC",
	},
	chimecho: {
		randomBattleMoves: ["psychic", "yawn", "recover", "calmmind", "shadowball", "healingwish", "healbell", "taunt"],
		randomDoubleBattleMoves: ["protect", "psychic", "thunderwave", "recover", "trickroom", "helpinghand", "taunt"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	absol: {
		randomBattleMoves: ["swordsdance", "suckerpunch", "knockoff", "superpower", "pursuit", "playrough"],
		randomDoubleBattleMoves: ["swordsdance", "suckerpunch", "knockoff", "superpower", "protect", "playrough"],
		tier: "PU",
		doublesTier: "(DUU)",
	},
	absolmega: {
		randomBattleMoves: ["icebeam", "knockoff", "playrough", "pursuit", "suckerpunch", "superpower", "swordsdance"],
		randomDoubleBattleMoves: ["swordsdance", "suckerpunch", "knockoff", "fireblast", "superpower", "protect", "playrough"],
		tier: "RUBL",
		doublesTier: "(DUU)",
	},
	snorunt: {
		tier: "LC",
	},
	glalie: {
		randomBattleMoves: ["spikes", "icebeam", "iceshard", "taunt", "earthquake", "explosion", "superfang"],
		randomDoubleBattleMoves: ["icebeam", "iceshard", "taunt", "earthquake", "freezedry", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	glaliemega: {
		randomBattleMoves: ["freezedry", "iceshard", "earthquake", "explosion", "return", "spikes"],
		randomDoubleBattleMoves: ["iceshard", "freezedry", "earthquake", "explosion", "protect", "return"],
		tier: "NU",
		doublesTier: "(DUU)",
	},
	froslass: {
		randomBattleMoves: ["icebeam", "spikes", "destinybond", "shadowball", "taunt", "thunderwave"],
		randomDoubleBattleMoves: ["icebeam", "protect", "destinybond", "shadowball", "taunt", "thunderwave", "willowisp"],
		tier: "UU",
		doublesTier: "(DUU)",
	},
	spheal: {
		tier: "LC",
	},
	sealeo: {
		tier: "NFE",
	},
	walrein: {
		randomBattleMoves: ["superfang", "protect", "toxic", "surf", "icebeam", "roar"],
		randomDoubleBattleMoves: ["protect", "icywind", "brine", "superfang"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	clamperl: {
		tier: "LC",
	},
	huntail: {
		randomBattleMoves: ["shellsmash", "waterfall", "icebeam", "suckerpunch"],
		randomDoubleBattleMoves: ["shellsmash", "waterfall", "icebeam", "suckerpunch", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	gorebyss: {
		randomBattleMoves: ["shellsmash", "hydropump", "icebeam", "hiddenpowergrass", "substitute"],
		randomDoubleBattleMoves: ["shellsmash", "hydropump", "icebeam", "hiddenpowergrass", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	relicanth: {
		randomBattleMoves: ["headsmash", "waterfall", "earthquake", "doubleedge", "stealthrock", "toxic"],
		randomDoubleBattleMoves: ["headsmash", "waterfall", "earthquake", "doubleedge", "rockslide", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	luvdisc: {
		randomBattleMoves: ["icebeam", "toxic", "sweetkiss", "protect", "scald"],
		randomDoubleBattleMoves: ["icebeam", "toxic", "sweetkiss", "protect", "scald", "icywind", "healpulse"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	bagon: {
		tier: "LC",
	},
	shelgon: {
		tier: "NFE",
	},
	salamence: {
		randomBattleMoves: ["dragondance", "earthquake", "fireblast", "fly", "outrage", "roost"],
		randomDoubleBattleMoves: ["protect", "fireblast", "earthquake", "dracometeor", "tailwind", "dragondance", "dragonclaw", "fly"],
		tier: "UUBL",
		doublesTier: "(DUU)",
	},
	salamencemega: {
		randomBattleMoves: ["doubleedge", "return", "fireblast", "earthquake", "dracometeor", "roost", "dragondance"],
		randomDoubleBattleMoves: ["doubleedge", "return", "fireblast", "earthquake", "dracometeor", "protect", "dragondance", "dragonclaw"],
		tier: "Uber",
		doublesTier: "DOU",
	},
	beldum: {
		tier: "LC",
	},
	metang: {
		tier: "NFE",
	},
	metagross: {
		randomBattleMoves: ["meteormash", "earthquake", "agility", "stealthrock", "zenheadbutt", "bulletpunch", "thunderpunch", "explosion", "icepunch"],
		randomDoubleBattleMoves: ["agility", "meteormash", "stompingtantrum", "protect", "zenheadbutt", "bulletpunch", "thunderpunch", "icepunch"],
		tier: "RU",
		doublesTier: "DUU",
	},
	metagrossmega: {
		randomBattleMoves: ["meteormash", "earthquake", "agility", "zenheadbutt", "hammerarm", "icepunch"],
		randomDoubleBattleMoves: ["meteormash", "stompingtantrum", "protect", "zenheadbutt", "thunderpunch", "icepunch"],
		tier: "Uber",
		doublesTier: "DOU",
	},
	regirock: {
		randomBattleMoves: ["stealthrock", "thunderwave", "stoneedge", "drainpunch", "curse", "rest", "rockslide", "toxic"],
		randomDoubleBattleMoves: ["stealthrock", "thunderwave", "stoneedge", "drainpunch", "curse", "rockslide", "protect", "rest"],
		tier: "PU",
		doublesTier: "(DUU)",
	},
	regice: {
		randomBattleMoves: ["thunderwave", "icebeam", "thunderbolt", "rest", "sleeptalk", "focusblast", "rockpolish"],
		randomDoubleBattleMoves: ["thunderwave", "icebeam", "thunderbolt", "icywind", "protect", "rockpolish"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	registeel: {
		randomBattleMoves: ["stealthrock", "toxic", "curse", "ironhead", "rest", "sleeptalk"],
		randomDoubleBattleMoves: ["stealthrock", "ironhead", "curse", "rest", "thunderwave", "protect", "seismictoss"],
		tier: "RU",
		doublesTier: "(DUU)",
	},
	latias: {
		randomBattleMoves: ["dracometeor", "healingwish", "hiddenpowerfire", "psychic", "trick"],
		randomDoubleBattleMoves: ["dracometeor", "psyshock", "tailwind", "helpinghand", "healpulse", "protect"],
		tier: "UU",
		doublesTier: "(DUU)",
	},
	latiasmega: {
		randomBattleMoves: ["calmmind", "defog", "dracometeor", "psyshock", "roost", "surf"],
		randomDoubleBattleMoves: ["dragonpulse", "psychic", "tailwind", "helpinghand", "healpulse", "protect"],
		tier: "OU",
		doublesTier: "(DUU)",
	},
	latios: {
		randomBattleMoves: ["dracometeor", "hiddenpowerfire", "psyshock", "surf", "thunderbolt", "trick"],
		randomDoubleBattleMoves: ["dracometeor", "dragonpulse", "psyshock", "trick", "tailwind", "protect", "hiddenpowerfire"],
		tier: "UUBL",
		doublesTier: "(DUU)",
	},
	latiosmega: {
		randomBattleMoves: ["calmmind", "defog", "dracometeor", "hiddenpowerfire", "psyshock", "roost"],
		randomDoubleBattleMoves: ["dracometeor", "dragonpulse", "psyshock", "tailwind", "protect", "hiddenpowerfire"],
		tier: "UUBL",
		doublesTier: "(DUU)",
	},
	kyogre: {
		randomBattleMoves: ["waterspout", "originpulse", "scald", "thunder", "icebeam"],
		randomDoubleBattleMoves: ["waterspout", "originpulse", "thunder", "icebeam", "calmmind", "protect"],
		tier: "Uber",
		doublesTier: "DUber",
	},
	kyogreprimal: {
		randomBattleMoves: ["calmmind", "originpulse", "scald", "thunder", "icebeam", "toxic", "rest", "sleeptalk"],
		randomDoubleBattleMoves: ["originpulse", "thunder", "icebeam", "calmmind", "protect"],
		tier: "Uber",
		doublesTier: "DUber",
	},
	groudon: {
		randomBattleMoves: ["dragonclaw", "earthquake", "firepunch", "lavaplume", "roar", "stealthrock", "stoneedge", "thunderwave"],
		randomDoubleBattleMoves: ["precipiceblades", "rockslide", "protect", "stoneedge", "swordsdance", "rockpolish", "firepunch"],
		tier: "Uber",
		doublesTier: "DUber",
	},
	groudonprimal: {
		randomBattleMoves: ["firepunch", "lavaplume", "precipiceblades", "rockpolish", "stealthrock", "stoneedge", "swordsdance", "toxic"],
		randomDoubleBattleMoves: ["precipiceblades", "rockslide", "stoneedge", "swordsdance", "rockpolish", "firepunch", "protect"],
		tier: "Uber",
		doublesTier: "DUber",
	},
	rayquaza: {
		randomBattleMoves: ["dracometeor", "dragondance", "earthquake", "extremespeed", "outrage", "vcreate"],
		randomDoubleBattleMoves: ["tailwind", "vcreate", "extremespeed", "dragondance", "earthquake", "dracometeor", "dragonclaw", "protect"],
		tier: "Uber",
		doublesTier: "DUber",
	},
	rayquazamega: {
		randomDoubleBattleMoves: ["vcreate", "extremespeed", "swordsdance", "earthquake", "dragonascent", "dragonclaw", "dragondance", "protect"],
		tier: "AG",
		doublesTier: "DUber",
	},
	jirachi: {
		randomBattleMoves: ["ironhead", "uturn", "firepunch", "icepunch", "stealthrock", "bodyslam", "toxic", "wish", "substitute"],
		randomDoubleBattleMoves: ["bodyslam", "ironhead", "icywind", "thunderwave", "helpinghand", "uturn", "followme", "protect"],
		tier: "OU",
		doublesTier: "DUber",
	},
	deoxys: {
		randomBattleMoves: ["psychoboost", "stealthrock", "spikes", "firepunch", "superpower", "extremespeed", "knockoff", "taunt"],
		randomDoubleBattleMoves: ["psychoboost", "superpower", "extremespeed", "icebeam", "firepunch", "protect", "knockoff"],
		tier: "Uber",
		doublesTier: "(DUU)",
	},
	deoxysattack: {
		randomBattleMoves: ["psychoboost", "superpower", "icebeam", "knockoff", "extremespeed", "firepunch", "stealthrock"],
		randomDoubleBattleMoves: ["psychoboost", "superpower", "extremespeed", "icebeam", "firepunch", "protect", "knockoff"],
		tier: "Uber",
		doublesTier: "DUU",
	},
	deoxysdefense: {
		randomBattleMoves: ["spikes", "stealthrock", "recover", "taunt", "toxic", "seismictoss", "knockoff"],
		randomDoubleBattleMoves: ["protect", "stealthrock", "recover", "taunt", "reflect", "seismictoss", "lightscreen", "trickroom"],
		tier: "Uber",
		doublesTier: "(DUU)",
	},
	deoxysspeed: {
		randomBattleMoves: ["spikes", "stealthrock", "superpower", "psychoboost", "taunt", "magiccoat", "knockoff"],
		randomDoubleBattleMoves: ["superpower", "psychoboost", "taunt", "lightscreen", "reflect", "protect", "knockoff"],
		tier: "Uber",
		doublesTier: "(DUU)",
	},
	turtwig: {
		tier: "LC",
	},
	grotle: {
		tier: "NFE",
	},
	torterra: {
		randomBattleMoves: ["stealthrock", "earthquake", "woodhammer", "stoneedge", "synthesis", "rockpolish"],
		randomDoubleBattleMoves: ["protect", "earthquake", "woodhammer", "stoneedge", "rockslide", "wideguard", "rockpolish"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	chimchar: {
		tier: "LC",
	},
	monferno: {
		tier: "NFE",
	},
	infernape: {
		randomBattleMoves: ["closecombat", "fireblast", "flareblitz", "focusblast", "grassknot", "nastyplot", "stealthrock", "stoneedge", "uturn", "vacuumwave"],
		randomDoubleBattleMoves: ["fakeout", "heatwave", "closecombat", "uturn", "grassknot", "stoneedge", "feint", "taunt", "flareblitz", "protect"],
		tier: "UU",
		doublesTier: "(DUU)",
	},
	piplup: {
		tier: "LC",
	},
	prinplup: {
		tier: "NFE",
	},
	empoleon: {
		randomBattleMoves: ["hydropump", "flashcannon", "grassknot", "defog", "icebeam", "scald", "toxic", "roar", "stealthrock"],
		randomDoubleBattleMoves: ["icywind", "scald", "protect", "grassknot", "flashcannon", "defog"],
		tier: "UU",
		doublesTier: "(DUU)",
	},
	starly: {
		tier: "LC",
	},
	staravia: {
		tier: "NFE",
	},
	staraptor: {
		randomBattleMoves: ["bravebird", "closecombat", "uturn", "quickattack", "doubleedge"],
		randomDoubleBattleMoves: ["bravebird", "closecombat", "uturn", "quickattack", "doubleedge", "tailwind", "protect"],
		tier: "UUBL",
		doublesTier: "(DUU)",
	},
	bidoof: {
		tier: "LC",
	},
	bibarel: {
		randomBattleMoves: ["return", "liquidation", "swordsdance", "quickattack", "aquajet"],
		randomDoubleBattleMoves: ["return", "liquidation", "swordsdance", "aquajet", "quickattack"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	kricketot: {
		tier: "LC",
	},
	kricketune: {
		randomBattleMoves: ["leechlife", "endeavor", "taunt", "toxic", "stickyweb", "knockoff"],
		randomDoubleBattleMoves: ["leechlife", "protect", "taunt", "stickyweb", "knockoff"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	shinx: {
		tier: "LC",
	},
	luxio: {
		tier: "NFE",
	},
	luxray: {
		randomBattleMoves: ["wildcharge", "icefang", "voltswitch", "crunch", "superpower", "facade"],
		randomDoubleBattleMoves: ["wildcharge", "icefang", "voltswitch", "crunch", "superpower", "helpinghand", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	cranidos: {
		tier: "LC",
	},
	rampardos: {
		randomBattleMoves: ["headsmash", "earthquake", "rockpolish", "crunch", "rockslide", "firepunch"],
		randomDoubleBattleMoves: ["headsmash", "earthquake", "zenheadbutt", "rockslide", "crunch", "stoneedge", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	shieldon: {
		tier: "LC",
	},
	bastiodon: {
		randomBattleMoves: ["stealthrock", "rockblast", "metalburst", "protect", "toxic", "roar"],
		randomDoubleBattleMoves: ["stealthrock", "stoneedge", "metalburst", "protect", "wideguard", "guardsplit"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	burmy: {
		tier: "LC",
	},
	wormadam: {
		randomBattleMoves: ["gigadrain", "bugbuzz", "quiverdance", "hiddenpowerrock", "leafstorm"],
		randomDoubleBattleMoves: ["leafstorm", "gigadrain", "bugbuzz", "stringshot", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	wormadamsandy: {
		randomBattleMoves: ["earthquake", "toxic", "protect", "stealthrock"],
		randomDoubleBattleMoves: ["earthquake", "suckerpunch", "rockblast", "protect", "stringshot"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	wormadamtrash: {
		randomBattleMoves: ["stealthrock", "toxic", "gyroball", "protect"],
		randomDoubleBattleMoves: ["strugglebug", "stringshot", "bugbuzz", "flashcannon", "suckerpunch", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	mothim: {
		randomBattleMoves: ["quiverdance", "bugbuzz", "airslash", "energyball", "uturn"],
		randomDoubleBattleMoves: ["quiverdance", "bugbuzz", "airslash", "energyball", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	combee: {
		tier: "LC",
	},
	vespiquen: {
		randomBattleMoves: ["toxic", "protect", "roost", "infestation", "uturn"],
		randomDoubleBattleMoves: ["tailwind", "healorder", "stringshot", "attackorder", "strugglebug", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	pachirisu: {
		randomBattleMoves: ["nuzzle", "thunderbolt", "superfang", "toxic", "uturn"],
		randomDoubleBattleMoves: ["nuzzle", "thunderbolt", "superfang", "followme", "uturn", "helpinghand", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	buizel: {
		tier: "LC",
	},
	floatzel: {
		randomBattleMoves: ["bulkup", "liquidation", "icepunch", "substitute", "taunt", "aquajet", "brickbreak"],
		randomDoubleBattleMoves: ["liquidation", "aquajet", "switcheroo", "protect", "icepunch", "taunt"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	cherubi: {
		tier: "LC",
	},
	cherrim: {
		randomBattleMoves: ["energyball", "dazzlinggleam", "hiddenpowerfire", "synthesis", "healingwish"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	cherrimsunshine: {
		randomBattleMoves: ["sunnyday", "solarbeam", "gigadrain", "weatherball", "hiddenpowerice"],
		randomDoubleBattleMoves: ["sunnyday", "solarbeam", "gigadrain", "weatherball", "helpinghand"],
	},
	shellos: {
		tier: "LC",
	},
	gastrodon: {
		randomBattleMoves: ["earthquake", "icebeam", "scald", "toxic", "recover", "clearsmog"],
		randomDoubleBattleMoves: ["earthpower", "scald", "muddywater", "recover", "icywind", "protect"],
		tier: "PU",
		doublesTier: "DOU",
	},
	drifloon: {
		tier: "LC Uber",
	},
	drifblim: {
		randomBattleMoves: ["acrobatics", "willowisp", "substitute", "destinybond", "shadowball", "hex"],
		randomDoubleBattleMoves: ["acrobatics", "shadowball", "hypnosis", "thunderbolt", "destinybond", "willowisp", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	buneary: {
		tier: "LC",
	},
	lopunny: {
		randomBattleMoves: ["highjumpkick", "icepunch", "return", "switcheroo"],
		randomDoubleBattleMoves: ["return", "switcheroo", "firepunch", "helpinghand", "fakeout", "protect", "encore", "thunderwave"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	lopunnymega: {
		randomBattleMoves: ["return", "highjumpkick", "substitute", "fakeout", "icepunch"],
		randomDoubleBattleMoves: ["return", "highjumpkick", "protect", "fakeout", "icepunch", "encore"],
		tier: "OU",
		doublesTier: "DUU",
	},
	glameow: {
		tier: "LC",
	},
	purugly: {
		randomBattleMoves: ["fakeout", "uturn", "suckerpunch", "quickattack", "return", "knockoff"],
		randomDoubleBattleMoves: ["fakeout", "uturn", "quickattack", "return", "knockoff", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	stunky: {
		tier: "LC",
	},
	skuntank: {
		randomBattleMoves: ["pursuit", "suckerpunch", "crunch", "fireblast", "taunt", "poisonjab", "defog"],
		randomDoubleBattleMoves: ["protect", "suckerpunch", "crunch", "fireblast", "taunt", "poisonjab", "snarl"],
		tier: "PU",
		doublesTier: "(DUU)",
	},
	bronzor: {
		tier: "LC",
	},
	bronzong: {
		randomBattleMoves: ["earthquake", "explosion", "ironhead", "lightscreen", "reflect", "stealthrock", "toxic"],
		randomDoubleBattleMoves: ["earthquake", "protect", "reflect", "lightscreen", "trickroom", "explosion", "gyroball"],
		tier: "RU",
		doublesTier: "DUU",
	},
	chatot: {
		randomBattleMoves: ["nastyplot", "boomburst", "heatwave", "hiddenpowerground", "substitute", "chatter", "uturn"],
		randomDoubleBattleMoves: ["nastyplot", "heatwave", "encore", "chatter", "uturn", "protect", "hypervoice", "boomburst"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	spiritomb: {
		randomBattleMoves: ["willowisp", "pursuit", "shadowsneak", "calmmind", "darkpulse", "rest", "sleeptalk", "psychic"],
		randomDoubleBattleMoves: ["shadowsneak", "icywind", "willowisp", "snarl", "protect", "foulplay"],
		tier: "PU",
		doublesTier: "(DUU)",
	},
	gible: {
		tier: "LC",
	},
	gabite: {
		tier: "NFE",
	},
	garchomp: {
		randomBattleMoves: ["outrage", "dragonclaw", "earthquake", "stoneedge", "fireblast", "swordsdance", "stealthrock", "firefang"],
		randomDoubleBattleMoves: ["dragonclaw", "earthquake", "stoneedge", "rockslide", "swordsdance", "protect"],
		tier: "OU",
		doublesTier: "DOU",
	},
	garchompmega: {
		randomBattleMoves: ["outrage", "dracometeor", "earthquake", "stoneedge", "fireblast", "swordsdance"],
		randomDoubleBattleMoves: ["dragonclaw", "earthquake", "stoneedge", "rockslide", "swordsdance", "protect", "fireblast"],
		tier: "(OU)",
		doublesTier: "(DOU)",
	},
	riolu: {
		tier: "LC",
	},
	lucario: {
		randomBattleMoves: ["aurasphere", "closecombat", "crunch", "darkpulse", "extremespeed", "flashcannon", "meteormash", "nastyplot", "swordsdance", "vacuumwave"],
		randomDoubleBattleMoves: ["closecombat", "extremespeed", "icepunch", "darkpulse", "meteormash", "protect"],
		tier: "UU",
		doublesTier: "(DUU)",
	},
	lucariomega: {
		randomBattleMoves: ["aurasphere", "closecombat", "extremespeed", "flashcannon", "icepunch", "meteormash", "nastyplot", "swordsdance", "vacuumwave"],
		randomDoubleBattleMoves: ["closecombat", "extremespeed", "icepunch", "meteormash", "darkpulse", "protect", "swordsdance"],
		tier: "Uber",
		doublesTier: "(DUU)",
	},
	hippopotas: {
		tier: "LC",
	},
	hippowdon: {
		randomBattleMoves: ["earthquake", "slackoff", "whirlwind", "stealthrock", "toxic", "stoneedge"],
		randomDoubleBattleMoves: ["earthquake", "slackoff", "rockslide", "stealthrock", "protect", "stoneedge", "whirlwind"],
		tier: "UU",
		doublesTier: "(DUU)",
	},
	skorupi: {
		tier: "LC",
	},
	drapion: {
		randomBattleMoves: ["knockoff", "taunt", "toxicspikes", "poisonjab", "whirlwind", "swordsdance", "aquatail", "earthquake"],
		randomDoubleBattleMoves: ["snarl", "taunt", "protect", "aquatail", "swordsdance", "poisonjab", "knockoff"],
		tier: "RU",
		doublesTier: "(DUU)",
	},
	croagunk: {
		tier: "LC",
	},
	toxicroak: {
		randomBattleMoves: ["swordsdance", "gunkshot", "drainpunch", "suckerpunch", "icepunch", "substitute"],
		randomDoubleBattleMoves: ["suckerpunch", "drainpunch", "swordsdance", "icepunch", "gunkshot", "fakeout", "protect"],
		tier: "RU",
		doublesTier: "(DUU)",
	},
	carnivine: {
		randomBattleMoves: ["swordsdance", "powerwhip", "return", "sleeppowder", "substitute", "knockoff"],
		randomDoubleBattleMoves: ["swordsdance", "powerwhip", "return", "sleeppowder", "knockoff", "ragepowder", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	finneon: {
		tier: "LC",
	},
	lumineon: {
		randomBattleMoves: ["scald", "icebeam", "uturn", "toxic", "defog"],
		randomDoubleBattleMoves: ["uturn", "icebeam", "toxic", "tailwind", "scald", "protect", "defog"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	snover: {
		tier: "LC",
	},
	abomasnow: {
		randomBattleMoves: ["woodhammer", "iceshard", "blizzard", "gigadrain", "leechseed", "substitute", "focuspunch", "earthquake"],
		randomDoubleBattleMoves: ["blizzard", "iceshard", "gigadrain", "protect", "woodhammer", "earthquake"],
		tier: "PU",
		doublesTier: "(DUU)",
	},
	abomasnowmega: {
		randomBattleMoves: ["blizzard", "gigadrain", "woodhammer", "earthquake", "iceshard", "hiddenpowerfire"],
		randomDoubleBattleMoves: ["blizzard", "iceshard", "gigadrain", "protect", "woodhammer", "earthquake"],
		tier: "NU",
		doublesTier: "DUU",
	},
	rotom: {
		randomBattleMoves: ["thunderbolt", "voltswitch", "shadowball", "substitute", "painsplit", "hiddenpowerice", "trick", "willowisp"],
		randomDoubleBattleMoves: ["thunderbolt", "voltswitch", "shadowball", "hiddenpowerice", "trick", "willowisp", "electroweb", "protect"],
		tier: "NU",
		doublesTier: "(DUU)",
	},
	rotomheat: {
		randomBattleMoves: ["overheat", "thunderbolt", "voltswitch", "hiddenpowerice", "painsplit", "willowisp"],
		randomDoubleBattleMoves: ["overheat", "thunderbolt", "voltswitch", "willowisp", "electroweb", "protect"],
		tier: "UU",
		doublesTier: "(DUU)",
	},
	rotomwash: {
		randomBattleMoves: ["hydropump", "thunderbolt", "voltswitch", "painsplit", "defog", "willowisp", "trick"],
		randomDoubleBattleMoves: ["hydropump", "thunderbolt", "voltswitch", "willowisp", "trick", "electroweb", "protect"],
		tier: "OU",
		doublesTier: "DUU",
	},
	rotomfrost: {
		randomBattleMoves: ["blizzard", "thunderbolt", "voltswitch", "painsplit", "willowisp", "trick"],
		randomDoubleBattleMoves: ["blizzard", "thunderbolt", "voltswitch", "willowisp", "trick", "electroweb", "protect"],
		tier: "PU",
		doublesTier: "(DUU)",
	},
	rotomfan: {
		randomBattleMoves: ["airslash", "thunderbolt", "voltswitch", "painsplit", "willowisp", "defog"],
		randomDoubleBattleMoves: ["airslash", "thunderbolt", "voltswitch", "willowisp", "electroweb", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	rotommow: {
		randomBattleMoves: ["leafstorm", "thunderbolt", "voltswitch", "hiddenpowerfire", "hiddenpowerice", "trick"],
		randomDoubleBattleMoves: ["leafstorm", "thunderbolt", "voltswitch", "hiddenpowerfire", "willowisp", "trick", "electroweb", "protect"],
		tier: "RU",
		doublesTier: "(DUU)",
	},
	uxie: {
		randomBattleMoves: ["stealthrock", "thunderwave", "psychic", "uturn", "healbell", "knockoff", "yawn"],
		randomDoubleBattleMoves: ["uturn", "psychic", "yawn", "stealthrock", "knockoff", "protect", "helpinghand", "thunderwave"],
		tier: "RU",
		doublesTier: "(DUU)",
	},
	mesprit: {
		randomBattleMoves: ["calmmind", "psychic", "psyshock", "energyball", "signalbeam", "hiddenpowerfire", "icebeam", "healingwish", "stealthrock", "uturn"],
		randomDoubleBattleMoves: ["calmmind", "psychic", "thunderbolt", "icebeam", "uturn", "trick", "protect", "knockoff", "helpinghand"],
		tier: "NU",
		doublesTier: "(DUU)",
	},
	azelf: {
		randomBattleMoves: ["nastyplot", "psyshock", "fireblast", "dazzlinggleam", "stealthrock", "knockoff", "taunt", "explosion"],
		randomDoubleBattleMoves: ["nastyplot", "psychic", "fireblast", "thunderbolt", "knockoff", "uturn", "taunt", "protect"],
		tier: "UU",
		doublesTier: "(DUU)",
	},
	dialga: {
		randomBattleMoves: ["stealthrock", "toxic", "dracometeor", "fireblast", "flashcannon", "roar", "thunderbolt"],
		randomDoubleBattleMoves: ["dracometeor", "dragonpulse", "protect", "thunderbolt", "flashcannon", "earthpower", "fireblast"],
		tier: "Uber",
		doublesTier: "DUber",
	},
	palkia: {
		randomBattleMoves: ["spacialrend", "dracometeor", "hydropump", "thunderwave", "dragontail", "fireblast"],
		randomDoubleBattleMoves: ["spacialrend", "dracometeor", "hydropump", "thunderbolt", "fireblast", "protect"],
		tier: "Uber",
		doublesTier: "DUber",
	},
	heatran: {
		randomBattleMoves: ["magmastorm", "lavaplume", "stealthrock", "earthpower", "flashcannon", "protect", "toxic", "roar"],
		randomDoubleBattleMoves: ["heatwave", "earthpower", "protect", "flashcannon", "willowisp"],
		tier: "OU",
		doublesTier: "DOU",
	},
	regigigas: {
		randomBattleMoves: ["thunderwave", "confuseray", "substitute", "return", "knockoff", "drainpunch"],
		randomDoubleBattleMoves: ["thunderwave", "substitute", "return", "icywind", "knockoff", "wideguard"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	giratina: {
		randomBattleMoves: ["calmmind", "dracometeor", "rest", "roar", "shadowball", "sleeptalk", "willowisp"],
		randomDoubleBattleMoves: ["tailwind", "protect", "dragontail", "willowisp", "calmmind", "dragonpulse", "shadowball"],
		tier: "Uber",
		doublesTier: "DUber",
	},
	giratinaorigin: {
		randomBattleMoves: ["defog", "dracometeor", "earthquake", "hex", "shadowsneak", "thunderwave", "willowisp"],
		randomDoubleBattleMoves: ["dracometeor", "shadowsneak", "tailwind", "willowisp", "dragonpulse", "shadowball", "protect"],
	},
	cresselia: {
		randomBattleMoves: ["moonlight", "psychic", "icebeam", "thunderwave", "toxic", "substitute", "psyshock", "moonblast", "calmmind"],
		randomDoubleBattleMoves: ["psyshock", "icywind", "thunderwave", "trickroom", "moonblast", "moonlight", "allyswitch", "protect", "helpinghand"],
		tier: "RU",
		doublesTier: "DOU",
	},
	phione: {
		randomBattleMoves: ["scald", "knockoff", "uturn", "icebeam", "toxic", "healbell"],
		randomDoubleBattleMoves: ["scald", "uturn", "helpinghand", "icywind", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	manaphy: {
		randomBattleMoves: ["tailglow", "surf", "icebeam", "energyball", "psychic"],
		randomDoubleBattleMoves: ["tailglow", "surf", "icebeam", "energyball", "protect", "scald", "helpinghand"],
		tier: "OU",
		doublesTier: "(DUU)",
	},
	darkrai: {
		randomBattleMoves: ["darkpulse", "focusblast", "hypnosis", "nastyplot", "sludgebomb", "trick"],
		randomDoubleBattleMoves: ["darkpulse", "focusblast", "nastyplot", "snarl", "sludgebomb", "protect"],
		tier: "Uber",
		doublesTier: "DUU",
	},
	shaymin: {
		randomBattleMoves: ["seedflare", "earthpower", "airslash", "psychic", "rest", "substitute", "leechseed"],
		randomDoubleBattleMoves: ["seedflare", "earthpower", "airslash", "rest", "substitute", "leechseed", "tailwind", "protect"],
		tier: "RU",
		doublesTier: "(DUU)",
	},
	shayminsky: {
		randomBattleMoves: ["seedflare", "airslash", "earthpower", "hiddenpowerice", "substitute", "leechseed"],
		randomDoubleBattleMoves: ["seedflare", "earthpower", "airslash", "rest", "tailwind", "protect", "hiddenpowerice"],
		tier: "Uber",
		doublesTier: "DUU",
	},
	arceus: {
		randomBattleMoves: ["swordsdance", "extremespeed", "shadowclaw", "earthquake", "recover"],
		randomDoubleBattleMoves: ["swordsdance", "extremespeed", "shadowclaw", "earthquake", "recover", "protect"],
		tier: "Uber",
		doublesTier: "DUber",
	},
	arceusbug: {
		randomBattleMoves: ["swordsdance", "xscissor", "stoneedge", "recover", "earthquake", "ironhead"],
		randomDoubleBattleMoves: ["swordsdance", "xscissor", "stoneedge", "recover", "earthquake", "ironhead", "protect"],
	},
	arceusdark: {
		randomBattleMoves: ["calmmind", "judgment", "recover", "fireblast", "toxic"],
		randomDoubleBattleMoves: ["calmmind", "judgment", "recover", "focusblast", "snarl", "willowisp", "protect"],
	},
	arceusdragon: {
		randomBattleMoves: ["swordsdance", "outrage", "extremespeed", "earthquake", "recover", "judgment", "fireblast", "willowisp", "defog"],
		randomDoubleBattleMoves: ["swordsdance", "dragonclaw", "extremespeed", "earthquake", "recover", "protect"],
	},
	arceuselectric: {
		randomBattleMoves: ["calmmind", "judgment", "recover", "icebeam", "earthpower"],
		randomDoubleBattleMoves: ["calmmind", "judgment", "recover", "icebeam", "protect"],
	},
	arceusfairy: {
		randomBattleMoves: ["calmmind", "judgment", "recover", "willowisp", "defog", "earthpower", "toxic"],
		randomDoubleBattleMoves: ["calmmind", "judgment", "recover", "willowisp", "protect", "earthpower", "thunderbolt", "defog"],
	},
	arceusfighting: {
		randomBattleMoves: ["calmmind", "judgment", "stoneedge", "shadowball", "recover", "roar", "icebeam"],
		randomDoubleBattleMoves: ["calmmind", "judgment", "icebeam", "shadowball", "recover", "willowisp", "protect"],
	},
	arceusfire: {
		randomBattleMoves: ["calmmind", "fireblast", "roar", "thunderbolt", "icebeam", "recover"],
		randomDoubleBattleMoves: ["calmmind", "judgment", "thunderbolt", "recover", "heatwave", "protect", "willowisp"],
	},
	arceusflying: {
		randomBattleMoves: ["calmmind", "judgment", "earthpower", "fireblast", "toxic", "recover"],
		randomDoubleBattleMoves: ["calmmind", "judgment", "recover", "tailwind", "protect", "earthpower"],
	},
	arceusghost: {
		randomBattleMoves: ["swordsdance", "shadowforce", "shadowclaw", "brickbreak", "extremespeed", "recover", "judgment", "toxic", "defog"],
		randomDoubleBattleMoves: ["calmmind", "judgment", "focusblast", "recover", "swordsdance", "shadowforce", "brickbreak", "willowisp", "protect"],
	},
	arceusgrass: {
		randomBattleMoves: ["judgment", "recover", "calmmind", "icebeam", "fireblast"],
		randomDoubleBattleMoves: ["calmmind", "icebeam", "judgment", "heatwave", "recover", "thunderwave", "protect"],
	},
	arceusground: {
		randomBattleMoves: ["swordsdance", "earthquake", "stoneedge", "recover", "judgment", "icebeam", "toxic", "stealthrock"],
		randomDoubleBattleMoves: ["swordsdance", "earthquake", "stoneedge", "recover", "calmmind", "judgment", "icebeam", "rockslide", "protect"],
	},
	arceusice: {
		randomBattleMoves: ["calmmind", "judgment", "thunderbolt", "fireblast", "recover"],
		randomDoubleBattleMoves: ["calmmind", "judgment", "thunderbolt", "focusblast", "recover", "protect", "icywind"],
	},
	arceuspoison: {
		randomBattleMoves: ["calmmind", "sludgebomb", "fireblast", "recover", "icebeam", "defog"],
		randomDoubleBattleMoves: ["calmmind", "judgment", "sludgebomb", "heatwave", "recover", "willowisp", "protect", "earthpower"],
	},
	arceuspsychic: {
		randomBattleMoves: ["judgment", "calmmind", "fireblast", "recover", "icebeam", "toxic"],
		randomDoubleBattleMoves: ["calmmind", "psyshock", "focusblast", "recover", "willowisp", "judgment", "protect"],
	},
	arceusrock: {
		randomBattleMoves: ["swordsdance", "earthquake", "stoneedge", "recover", "judgment", "willowisp", "stealthrock"],
		randomDoubleBattleMoves: ["swordsdance", "stoneedge", "recover", "rockslide", "earthquake", "protect"],
	},
	arceussteel: {
		randomBattleMoves: ["judgment", "recover", "willowisp", "defog", "roar", "swordsdance", "ironhead", "earthquake", "stoneedge"],
		randomDoubleBattleMoves: ["calmmind", "judgment", "recover", "protect", "willowisp", "earthpower"],
	},
	arceuswater: {
		randomBattleMoves: ["recover", "calmmind", "judgment", "icebeam", "toxic", "defog"],
		randomDoubleBattleMoves: ["recover", "calmmind", "judgment", "icebeam", "fireblast", "icywind", "surf", "protect"],
	},
	victini: {
		randomBattleMoves: ["vcreate", "boltstrike", "uturn", "zenheadbutt", "grassknot", "focusblast", "blueflare"],
		randomDoubleBattleMoves: ["vcreate", "boltstrike", "uturn", "psychic", "blueflare", "protect"],
		tier: "OU",
		doublesTier: "DOU",
	},
	snivy: {
		tier: "LC",
	},
	servine: {
		tier: "NFE",
	},
	serperior: {
		randomBattleMoves: ["leafstorm", "dragonpulse", "hiddenpowerfire", "substitute", "leechseed", "glare"],
		randomDoubleBattleMoves: ["leafstorm", "hiddenpowerfire", "taunt", "dragonpulse", "protect"],
		tier: "OU",
		doublesTier: "(DUU)",
	},
	tepig: {
		tier: "LC",
	},
	pignite: {
		tier: "NFE",
	},
	emboar: {
		randomBattleMoves: ["flareblitz", "superpower", "wildcharge", "headsmash", "fireblast", "grassknot", "suckerpunch"],
		randomDoubleBattleMoves: ["flareblitz", "superpower", "wildcharge", "headsmash", "protect", "heatwave", "rockslide"],
		tier: "NUBL",
		doublesTier: "(DUU)",
	},
	oshawott: {
		tier: "LC",
	},
	dewott: {
		tier: "NFE",
	},
	samurott: {
		randomBattleMoves: ["swordsdance", "liquidation", "aquajet", "megahorn", "sacredsword", "hydropump", "icebeam", "grassknot"],
		randomDoubleBattleMoves: ["hydropump", "aquajet", "icebeam", "scald", "hiddenpowergrass", "taunt", "helpinghand", "protect"],
		tier: "NU",
		doublesTier: "(DUU)",
	},
	patrat: {
		tier: "LC",
	},
	watchog: {
		randomBattleMoves: ["hypnosis", "substitute", "superfang", "swordsdance", "return", "knockoff"],
		randomDoubleBattleMoves: ["swordsdance", "knockoff", "hypnosis", "return", "superfang", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	lillipup: {
		tier: "LC",
	},
	herdier: {
		tier: "NFE",
	},
	stoutland: {
		randomBattleMoves: ["return", "crunch", "wildcharge", "superpower", "icefang"],
		randomDoubleBattleMoves: ["return", "wildcharge", "superpower", "crunch", "protect"],
		tier: "PU",
		doublesTier: "(DUU)",
	},
	purrloin: {
		tier: "LC",
	},
	liepard: {
		randomBattleMoves: ["knockoff", "playrough", "uturn", "copycat", "encore", "thunderwave", "nastyplot", "darkpulse", "substitute"],
		randomDoubleBattleMoves: ["encore", "thunderwave", "knockoff", "playrough", "uturn", "suckerpunch", "fakeout", "protect"],
		tier: "PU",
		doublesTier: "(DUU)",
	},
	pansage: {
		tier: "LC",
	},
	simisage: {
		randomBattleMoves: ["nastyplot", "gigadrain", "focusblast", "hiddenpowerice", "substitute", "leafstorm", "knockoff", "superpower"],
		randomDoubleBattleMoves: ["nastyplot", "leafstorm", "hiddenpowerfire", "hiddenpowerice", "gigadrain", "focusblast", "taunt", "helpinghand", "spikyshield"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	pansear: {
		tier: "LC",
	},
	simisear: {
		randomBattleMoves: ["substitute", "nastyplot", "fireblast", "focusblast", "grassknot", "hiddenpowerrock"],
		randomDoubleBattleMoves: ["nastyplot", "fireblast", "focusblast", "grassknot", "heatwave", "taunt", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	panpour: {
		tier: "LC",
	},
	simipour: {
		randomBattleMoves: ["substitute", "nastyplot", "hydropump", "icebeam", "focusblast"],
		randomDoubleBattleMoves: ["nastyplot", "hydropump", "icebeam", "taunt", "helpinghand", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	munna: {
		tier: "LC",
	},
	musharna: {
		randomBattleMoves: ["calmmind", "psychic", "psyshock", "signalbeam", "moonlight", "healbell", "thunderwave"],
		randomDoubleBattleMoves: ["trickroom", "thunderwave", "moonlight", "psychic", "helpinghand", "hypnosis", "signalbeam", "protect"],
		tier: "PU",
		doublesTier: "(DUU)",
	},
	pidove: {
		tier: "LC",
	},
	tranquill: {
		tier: "NFE",
	},
	unfezant: {
		randomBattleMoves: ["return", "pluck", "hypnosis", "tailwind", "uturn", "roost", "nightslash"],
		randomDoubleBattleMoves: ["pluck", "uturn", "return", "protect", "tailwind", "taunt", "roost", "nightslash"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	blitzle: {
		tier: "LC",
	},
	zebstrika: {
		randomBattleMoves: ["voltswitch", "hiddenpowergrass", "overheat", "wildcharge", "thunderbolt"],
		randomDoubleBattleMoves: ["voltswitch", "hiddenpowergrass", "overheat", "wildcharge", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	roggenrola: {
		tier: "LC",
	},
	boldore: {
		tier: "NFE",
	},
	gigalith: {
		randomBattleMoves: ["stealthrock", "rockblast", "earthquake", "explosion", "stoneedge", "superpower"],
		randomDoubleBattleMoves: ["stealthrock", "rockslide", "stompingtantrum", "stoneedge", "superpower", "wideguard", "protect"],
		tier: "RU",
		doublesTier: "(DUU)",
	},
	woobat: {
		tier: "LC",
	},
	swoobat: {
		randomBattleMoves: ["substitute", "calmmind", "storedpower", "heatwave", "airslash", "roost"],
		randomDoubleBattleMoves: ["calmmind", "psychic", "airslash", "protect", "heatwave", "tailwind"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	drilbur: {
		tier: "LC",
	},
	excadrill: {
		randomBattleMoves: ["swordsdance", "earthquake", "ironhead", "rockslide", "rapidspin"],
		randomDoubleBattleMoves: ["swordsdance", "drillrun", "earthquake", "rockslide", "ironhead", "protect"],
		tier: "OU",
		doublesTier: "DOU",
	},
	audino: {
		randomBattleMoves: ["wish", "protect", "healbell", "toxic", "thunderwave", "reflect", "lightscreen", "doubleedge"],
		randomDoubleBattleMoves: ["healpulse", "protect", "trickroom", "thunderwave", "helpinghand", "hypervoice"],
		tier: "PU",
		doublesTier: "(DUU)",
	},
	audinomega: {
		randomBattleMoves: ["wish", "calmmind", "healbell", "dazzlinggleam", "protect", "fireblast"],
		randomDoubleBattleMoves: ["healpulse", "protect", "trickroom", "thunderwave", "hypervoice", "helpinghand", "dazzlinggleam"],
		tier: "NU",
		doublesTier: "(DUU)",
	},
	timburr: {
		tier: "LC",
	},
	gurdurr: {
		tier: "PU",
		doublesTier: "NFE",
	},
	conkeldurr: {
		randomBattleMoves: ["bulkup", "drainpunch", "icepunch", "knockoff", "machpunch"],
		randomDoubleBattleMoves: ["machpunch", "drainpunch", "facade", "knockoff", "protect"],
		tier: "UUBL",
		doublesTier: "(DUU)",
	},
	tympole: {
		tier: "LC",
	},
	palpitoad: {
		tier: "NFE",
	},
	seismitoad: {
		randomBattleMoves: ["hydropump", "scald", "sludgewave", "earthquake", "knockoff", "stealthrock", "toxic", "raindance"],
		randomDoubleBattleMoves: ["hydropump", "muddywater", "sludgebomb", "earthquake", "raindance", "protect"],
		tier: "NU",
		doublesTier: "(DUU)",
	},
	throh: {
		randomBattleMoves: ["bulkup", "circlethrow", "icepunch", "stormthrow", "rest", "sleeptalk", "knockoff"],
		randomDoubleBattleMoves: ["helpinghand", "circlethrow", "icepunch", "stormthrow", "knockoff", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	sawk: {
		randomBattleMoves: ["closecombat", "earthquake", "icepunch", "poisonjab", "bulkup", "knockoff"],
		randomDoubleBattleMoves: ["closecombat", "knockoff", "icepunch", "rockslide", "protect"],
		tier: "PUBL",
		doublesTier: "(DUU)",
	},
	sewaddle: {
		tier: "LC",
	},
	swadloon: {
		tier: "NFE",
	},
	leavanny: {
		randomBattleMoves: ["stickyweb", "swordsdance", "leafblade", "xscissor", "knockoff"],
		randomDoubleBattleMoves: ["swordsdance", "leafblade", "xscissor", "protect", "stickyweb"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	venipede: {
		tier: "LC",
	},
	whirlipede: {
		tier: "NFE",
	},
	scolipede: {
		randomBattleMoves: ["protect", "spikes", "toxicspikes", "megahorn", "rockslide", "earthquake", "swordsdance", "poisonjab"],
		randomDoubleBattleMoves: ["protect", "megahorn", "rockslide", "poisonjab", "swordsdance", "aquatail", "superpower"],
		tier: "UUBL",
		doublesTier: "(DUU)",
	},
	cottonee: {
		tier: "LC",
	},
	whimsicott: {
		randomBattleMoves: ["encore", "taunt", "leechseed", "uturn", "toxic", "stunspore", "memento", "tailwind", "moonblast", "defog"],
		randomDoubleBattleMoves: ["encore", "taunt", "substitute", "leechseed", "uturn", "helpinghand", "stunspore", "moonblast", "tailwind", "dazzlinggleam", "gigadrain", "protect", "defog"],
		tier: "NU",
		doublesTier: "DOU",
	},
	petilil: {
		tier: "LC",
	},
	lilligant: {
		randomBattleMoves: ["sleeppowder", "quiverdance", "petaldance", "gigadrain", "hiddenpowerfire", "hiddenpowerrock"],
		randomDoubleBattleMoves: ["quiverdance", "gigadrain", "sleeppowder", "hiddenpowerice", "hiddenpowerfire", "hiddenpowerrock", "petaldance", "helpinghand", "protect"],
		tier: "PUBL",
		doublesTier: "(DUU)",
	},
	basculin: {
		randomBattleMoves: ["liquidation", "aquajet", "superpower", "crunch", "headsmash"],
		randomDoubleBattleMoves: ["liquidation", "aquajet", "superpower", "muddywater", "icebeam", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	basculinbluestriped: {
		randomBattleMoves: ["liquidation", "aquajet", "superpower", "crunch", "headsmash"],
		randomDoubleBattleMoves: ["liquidation", "aquajet", "superpower", "muddywater", "icebeam", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	sandile: {
		tier: "LC",
	},
	krokorok: {
		tier: "NFE",
	},
	krookodile: {
		randomBattleMoves: ["earthquake", "stoneedge", "pursuit", "knockoff", "stealthrock", "superpower"],
		randomDoubleBattleMoves: ["earthquake", "stoneedge", "protect", "knockoff", "superpower"],
		tier: "UU",
		doublesTier: "DUU",
	},
	darumaka: {
		tier: "LC",
	},
	darmanitan: {
		randomBattleMoves: ["uturn", "flareblitz", "rockslide", "earthquake", "superpower"],
		randomDoubleBattleMoves: ["uturn", "flareblitz", "rockslide", "earthquake", "superpower", "protect"],
		tier: "RUBL",
		doublesTier: "(DUU)",
	},
	maractus: {
		randomBattleMoves: ["spikes", "gigadrain", "leechseed", "hiddenpowerfire", "toxic", "suckerpunch", "spikyshield"],
		randomDoubleBattleMoves: ["energyball", "leechseed", "hiddenpowerfire", "helpinghand", "suckerpunch", "spikyshield"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	dwebble: {
		tier: "LC",
	},
	crustle: {
		randomBattleMoves: ["stealthrock", "spikes", "shellsmash", "earthquake", "rockblast", "xscissor", "stoneedge"],
		randomDoubleBattleMoves: ["protect", "shellsmash", "earthquake", "rockslide", "xscissor", "stoneedge"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	scraggy: {
		tier: "LC",
	},
	scrafty: {
		randomBattleMoves: ["dragondance", "icepunch", "highjumpkick", "drainpunch", "rest", "bulkup", "knockoff"],
		randomDoubleBattleMoves: ["fakeout", "drainpunch", "knockoff", "icepunch", "superfang", "protect"],
		tier: "NU",
		doublesTier: "DOU",
	},
	sigilyph: {
		randomBattleMoves: ["calmmind", "psychic", "psyshock", "heatwave", "roost", "airslash", "icebeam"],
		randomDoubleBattleMoves: ["psyshock", "heatwave", "airslash", "tailwind", "calmmind", "protect"],
		tier: "NU",
		doublesTier: "(DUU)",
	},
	yamask: {
		tier: "LC",
	},
	cofagrigus: {
		randomBattleMoves: ["nastyplot", "trickroom", "shadowball", "hiddenpowerfighting", "willowisp", "haze", "painsplit", "toxicspikes"],
		randomDoubleBattleMoves: ["nastyplot", "trickroom", "shadowball", "hiddenpowerfighting", "willowisp", "protect"],
		tier: "NUBL",
		doublesTier: "DUU",
	},
	tirtouga: {
		tier: "LC",
	},
	carracosta: {
		randomBattleMoves: ["shellsmash", "aquajet", "liquidation", "stoneedge", "earthquake"],
		randomDoubleBattleMoves: ["shellsmash", "aquajet", "liquidation", "stoneedge", "earthquake", "protect", "wideguard", "rockslide"],
		tier: "PU",
		doublesTier: "(DUU)",
	},
	archen: {
		tier: "LC",
	},
	archeops: {
		randomBattleMoves: ["headsmash", "acrobatics", "stoneedge", "earthquake", "aquatail", "uturn", "endeavor"],
		randomDoubleBattleMoves: ["stoneedge", "rockslide", "earthpower", "uturn", "acrobatics", "tailwind", "taunt", "protect"],
		tier: "PUBL",
		doublesTier: "(DUU)",
	},
	trubbish: {
		tier: "LC",
	},
	garbodor: {
		randomBattleMoves: ["spikes", "toxicspikes", "gunkshot", "haze", "painsplit", "toxic", "drainpunch"],
		randomDoubleBattleMoves: ["protect", "painsplit", "gunkshot", "drainpunch", "toxicspikes"],
		tier: "NU",
		doublesTier: "(DUU)",
	},
	zorua: {
		tier: "LC",
	},
	zoroark: {
		randomBattleMoves: ["suckerpunch", "darkpulse", "focusblast", "flamethrower", "uturn", "nastyplot", "knockoff", "trick", "sludgebomb"],
		randomDoubleBattleMoves: ["suckerpunch", "darkpulse", "focusblast", "flamethrower", "uturn", "nastyplot", "knockoff", "protect"],
		tier: "RUBL",
		doublesTier: "(DUU)",
	},
	minccino: {
		tier: "LC",
	},
	cinccino: {
		randomBattleMoves: ["tailslap", "bulletseed", "rockblast", "knockoff", "uturn"],
		randomDoubleBattleMoves: ["tailslap", "uturn", "knockoff", "bulletseed", "rockblast", "protect"],
		tier: "PUBL",
		doublesTier: "(DUU)",
	},
	gothita: {
		tier: "LC Uber",
	},
	gothorita: {
		tier: "NFE",
	},
	gothitelle: {
		randomBattleMoves: ["confide", "charm", "taunt", "rest"],
		randomDoubleBattleMoves: ["psychic", "thunderbolt", "shadowball", "trickroom", "taunt", "healpulse", "protect", "charm"],
		tier: "(PU)",
		doublesTier: "DOU",
	},
	solosis: {
		tier: "LC",
	},
	duosion: {
		tier: "NFE",
	},
	reuniclus: {
		randomBattleMoves: ["calmmind", "recover", "psychic", "focusblast", "shadowball", "trickroom", "psyshock"],
		randomDoubleBattleMoves: ["helpinghand", "psychic", "focusblast", "shadowball", "trickroom", "protect"],
		tier: "RUBL",
		doublesTier: "(DUU)",
	},
	ducklett: {
		tier: "LC",
	},
	swanna: {
		randomBattleMoves: ["bravebird", "roost", "hurricane", "icebeam", "raindance", "defog", "scald"],
		randomDoubleBattleMoves: ["bravebird", "hurricane", "icebeam", "tailwind", "scald", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	vanillite: {
		tier: "LC",
	},
	vanillish: {
		tier: "NFE",
	},
	vanilluxe: {
		randomBattleMoves: ["blizzard", "explosion", "hiddenpowerground", "flashcannon", "autotomize", "freezedry"],
		randomDoubleBattleMoves: ["blizzard", "taunt", "hiddenpowerground", "flashcannon", "autotomize", "protect", "freezedry"],
		tier: "NUBL",
		doublesTier: "(DUU)",
	},
	deerling: {
		tier: "LC",
	},
	sawsbuck: {
		randomBattleMoves: ["swordsdance", "hornleech", "jumpkick", "return", "substitute"],
		randomDoubleBattleMoves: ["swordsdance", "hornleech", "jumpkick", "return", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	emolga: {
		randomBattleMoves: ["thunderbolt", "acrobatics", "encore", "uturn", "knockoff", "roost", "toxic"],
		randomDoubleBattleMoves: ["helpinghand", "tailwind", "encore", "thunderbolt", "airslash", "roost", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	karrablast: {
		tier: "LC",
	},
	escavalier: {
		randomBattleMoves: ["megahorn", "pursuit", "ironhead", "knockoff", "swordsdance", "drillrun"],
		randomDoubleBattleMoves: ["megahorn", "protect", "ironhead", "knockoff", "swordsdance", "drillrun"],
		tier: "RU",
		doublesTier: "(DUU)",
	},
	foongus: {
		tier: "LC",
	},
	amoonguss: {
		randomBattleMoves: ["spore", "stunspore", "gigadrain", "clearsmog", "hiddenpowerfire", "synthesis", "sludgebomb", "foulplay"],
		randomDoubleBattleMoves: ["spore", "stunspore", "gigadrain", "ragepowder", "hiddenpowerfire", "sludgebomb", "protect"],
		tier: "UU",
		doublesTier: "DOU",
	},
	frillish: {
		tier: "LC",
	},
	jellicent: {
		randomBattleMoves: ["scald", "willowisp", "recover", "toxic", "shadowball", "icebeam", "taunt"],
		randomDoubleBattleMoves: ["scald", "willowisp", "recover", "trickroom", "shadowball", "icywind", "protect"],
		tier: "PU",
		doublesTier: "(DUU)",
	},
	alomomola: {
		randomBattleMoves: ["wish", "protect", "knockoff", "toxic", "scald"],
		randomDoubleBattleMoves: ["protect", "knockoff", "icywind", "scald", "helpinghand", "wideguard"],
		tier: "UU",
		doublesTier: "(DUU)",
	},
	joltik: {
		tier: "LC",
	},
	galvantula: {
		randomBattleMoves: ["thunder", "hiddenpowerice", "gigadrain", "bugbuzz", "voltswitch", "stickyweb"],
		randomDoubleBattleMoves: ["thunder", "hiddenpowerice", "energyball", "bugbuzz", "voltswitch", "stickyweb", "protect"],
		tier: "RU",
		doublesTier: "(DUU)",
	},
	ferroseed: {
		tier: "PU",
		doublesTier: "LC",
	},
	ferrothorn: {
		randomBattleMoves: ["spikes", "stealthrock", "leechseed", "powerwhip", "protect", "knockoff", "gyroball"],
		randomDoubleBattleMoves: ["gyroball", "stealthrock", "leechseed", "powerwhip", "knockoff", "protect"],
		tier: "OU",
		doublesTier: "DOU",
	},
	klink: {
		tier: "LC",
	},
	klang: {
		tier: "NFE",
	},
	klinklang: {
		randomBattleMoves: ["shiftgear", "return", "geargrind", "wildcharge", "substitute"],
		randomDoubleBattleMoves: ["shiftgear", "return", "geargrind", "wildcharge", "protect"],
		tier: "NU",
		doublesTier: "(DUU)",
	},
	tynamo: {
		tier: "LC",
	},
	eelektrik: {
		tier: "NFE",
	},
	eelektross: {
		randomBattleMoves: ["thunderbolt", "flamethrower", "uturn", "gigadrain", "knockoff", "superpower", "hiddenpowerice"],
		randomDoubleBattleMoves: ["thunderbolt", "flamethrower", "uturn", "voltswitch", "knockoff", "gigadrain", "protect"],
		tier: "PU",
		doublesTier: "(DUU)",
	},
	elgyem: {
		tier: "LC",
	},
	beheeyem: {
		randomBattleMoves: ["nastyplot", "psychic", "psyshock", "thunderbolt", "hiddenpowerfighting", "trick", "trickroom", "signalbeam"],
		randomDoubleBattleMoves: ["psychic", "thunderbolt", "hiddenpowerfighting", "recover", "trick", "trickroom", "signalbeam", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	litwick: {
		tier: "LC",
	},
	lampent: {
		tier: "NFE",
	},
	chandelure: {
		randomBattleMoves: ["calmmind", "shadowball", "energyball", "fireblast", "hiddenpowerground", "trick", "substitute", "painsplit"],
		randomDoubleBattleMoves: ["shadowball", "energyball", "overheat", "heatwave", "trick", "protect"],
		tier: "UU",
		doublesTier: "DUU",
	},
	axew: {
		tier: "LC",
	},
	fraxure: {
		tier: "NFE",
	},
	haxorus: {
		randomBattleMoves: ["dragondance", "swordsdance", "outrage", "earthquake", "poisonjab", "taunt"],
		randomDoubleBattleMoves: ["dragondance", "swordsdance", "protect", "dragonclaw", "earthquake", "poisonjab", "taunt"],
		tier: "UU",
		doublesTier: "(DUU)",
	},
	cubchoo: {
		tier: "LC",
	},
	beartic: {
		randomBattleMoves: ["iciclecrash", "superpower", "nightslash", "stoneedge", "swordsdance", "aquajet"],
		randomDoubleBattleMoves: ["iciclecrash", "superpower", "stoneedge", "swordsdance", "aquajet", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	cryogonal: {
		randomBattleMoves: ["icebeam", "recover", "toxic", "rapidspin", "haze", "freezedry", "hiddenpowerground"],
		randomDoubleBattleMoves: ["icebeam", "recover", "icywind", "protect", "freezedry", "hiddenpowerground"],
		tier: "PU",
		doublesTier: "(DUU)",
	},
	shelmet: {
		tier: "LC",
	},
	accelgor: {
		randomBattleMoves: ["spikes", "yawn", "bugbuzz", "focusblast", "energyball", "hiddenpowerrock", "encore", "toxicspikes"],
		randomDoubleBattleMoves: ["protect", "yawn", "bugbuzz", "focusblast", "energyball", "hiddenpowerrock", "encore", "sludgebomb"],
		tier: "NU",
		doublesTier: "(DUU)",
	},
	stunfisk: {
		randomBattleMoves: ["discharge", "earthpower", "scald", "toxic", "rest", "sleeptalk", "stealthrock"],
		randomDoubleBattleMoves: ["discharge", "earthpower", "scald", "electroweb", "protect", "stealthrock"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	mienfoo: {
		tier: "LC",
	},
	mienshao: {
		randomBattleMoves: ["uturn", "fakeout", "highjumpkick", "stoneedge", "poisonjab", "swordsdance", "knockoff"],
		randomDoubleBattleMoves: ["uturn", "fakeout", "highjumpkick", "stoneedge", "drainpunch", "swordsdance", "knockoff", "feint", "protect"],
		tier: "RUBL",
		doublesTier: "DUU",
	},
	druddigon: {
		randomBattleMoves: ["dragontail", "firepunch", "earthquake", "glare", "gunkshot", "outrage", "stealthrock", "suckerpunch"],
		randomDoubleBattleMoves: ["superpower", "earthquake", "suckerpunch", "dragonclaw", "glare", "protect", "firepunch", "thunderpunch"],
		tier: "NU",
		doublesTier: "(DUU)",
	},
	golett: {
		tier: "LC",
	},
	golurk: {
		randomBattleMoves: ["earthquake", "shadowpunch", "dynamicpunch", "icepunch", "stealthrock", "rockpolish"],
		randomDoubleBattleMoves: ["earthquake", "shadowpunch", "dynamicpunch", "icepunch", "stoneedge", "protect", "rockpolish"],
		tier: "PU",
		doublesTier: "(DUU)",
	},
	pawniard: {
		tier: "LC",
	},
	bisharp: {
		randomBattleMoves: ["swordsdance", "knockoff", "ironhead", "suckerpunch", "lowkick"],
		randomDoubleBattleMoves: ["swordsdance", "suckerpunch", "ironhead", "knockoff", "protect"],
		tier: "UU",
		doublesTier: "DUU",
	},
	bouffalant: {
		randomBattleMoves: ["headcharge", "earthquake", "stoneedge", "megahorn", "swordsdance", "superpower"],
		randomDoubleBattleMoves: ["headcharge", "stompingtantrum", "stoneedge", "megahorn", "swordsdance", "superpower", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	rufflet: {
		tier: "LC",
	},
	braviary: {
		randomBattleMoves: ["bravebird", "superpower", "return", "uturn", "substitute", "bulkup", "roost"],
		randomDoubleBattleMoves: ["bravebird", "superpower", "return", "uturn", "tailwind", "skydrop", "protect"],
		tier: "NU",
		doublesTier: "(DUU)",
	},
	vullaby: {
		tier: "LC",
	},
	mandibuzz: {
		randomBattleMoves: ["foulplay", "bravebird", "roost", "taunt", "toxic", "uturn", "defog"],
		randomDoubleBattleMoves: ["knockoff", "roost", "taunt", "tailwind", "snarl", "uturn", "bravebird", "protect"],
		tier: "RU",
		doublesTier: "(DUU)",
	},
	heatmor: {
		randomBattleMoves: ["fireblast", "suckerpunch", "focusblast", "gigadrain", "knockoff"],
		randomDoubleBattleMoves: ["firelash", "suckerpunch", "superpower", "gigadrain", "incinerate", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	durant: {
		randomBattleMoves: ["honeclaws", "ironhead", "xscissor", "rockslide", "superpower"],
		randomDoubleBattleMoves: ["honeclaws", "ironhead", "xscissor", "rockslide", "protect", "superpower"],
		tier: "RUBL",
		doublesTier: "(DUU)",
	},
	deino: {
		tier: "LC",
	},
	zweilous: {
		tier: "NFE",
	},
	hydreigon: {
		randomBattleMoves: ["uturn", "dracometeor", "dragonpulse", "earthpower", "fireblast", "darkpulse", "roost", "flashcannon", "superpower"],
		randomDoubleBattleMoves: ["uturn", "dracometeor", "fireblast", "darkpulse", "flashcannon", "tailwind", "protect"],
		tier: "UU",
		doublesTier: "DUU",
	},
	larvesta: {
		tier: "LC",
	},
	volcarona: {
		randomBattleMoves: ["quiverdance", "fierydance", "fireblast", "bugbuzz", "roost", "gigadrain", "hiddenpowerice", "hiddenpowerground"],
		randomDoubleBattleMoves: ["quiverdance", "fierydance", "bugbuzz", "gigadrain", "heatwave", "tailwind", "protect"],
		tier: "OU",
		doublesTier: "DOU",
	},
	cobalion: {
		randomBattleMoves: ["closecombat", "hiddenpowerice", "ironhead", "stealthrock", "stoneedge", "swordsdance", "taunt", "voltswitch"],
		randomDoubleBattleMoves: ["closecombat", "ironhead", "swordsdance", "stoneedge", "thunderwave", "protect"],
		tier: "UU",
		doublesTier: "(DUU)",
	},
	terrakion: {
		randomBattleMoves: ["swordsdance", "closecombat", "stoneedge", "earthquake", "stealthrock", "quickattack"],
		randomDoubleBattleMoves: ["stoneedge", "closecombat", "rockslide", "stompingtantrum", "taunt", "protect"],
		tier: "UU",
		doublesTier: "DOU",
	},
	virizion: {
		randomBattleMoves: ["swordsdance", "closecombat", "leafblade", "stoneedge", "calmmind", "focusblast", "gigadrain", "hiddenpowerice", "substitute"],
		randomDoubleBattleMoves: ["taunt", "closecombat", "stoneedge", "leafblade", "swordsdance", "protect"],
		tier: "RU",
		doublesTier: "(DUU)",
	},
	tornadus: {
		randomBattleMoves: ["hurricane", "heatwave", "superpower", "grassknot", "uturn", "defog", "tailwind"],
		randomDoubleBattleMoves: ["hurricane", "uturn", "superpower", "taunt", "heatwave", "tailwind", "protect", "skydrop"],
		tier: "RUBL",
		doublesTier: "(DUU)",
	},
	tornadustherian: {
		randomBattleMoves: ["hurricane", "heatwave", "knockoff", "superpower", "uturn", "taunt"],
		randomDoubleBattleMoves: ["hurricane", "uturn", "heatwave", "skydrop", "tailwind", "taunt", "protect"],
		tier: "OU",
		doublesTier: "(DUU)",
	},
	thundurus: {
		randomBattleMoves: ["thunderwave", "nastyplot", "thunderbolt", "hiddenpowerice", "hiddenpowerflying", "focusblast", "substitute", "knockoff", "taunt"],
		randomDoubleBattleMoves: ["thunderwave", "nastyplot", "thunderbolt", "hiddenpowerice", "hiddenpowerflying", "focusblast", "knockoff", "taunt", "protect"],
		tier: "UUBL",
		doublesTier: "DUU",
	},
	thundurustherian: {
		randomBattleMoves: ["nastyplot", "thunderbolt", "hiddenpowerflying", "hiddenpowerice", "focusblast", "voltswitch"],
		randomDoubleBattleMoves: ["nastyplot", "thunderbolt", "hiddenpowerflying", "hiddenpowerice", "focusblast", "voltswitch", "protect"],
		tier: "UUBL",
		doublesTier: "DUU",
	},
	reshiram: {
		randomBattleMoves: ["blueflare", "dracometeor", "dragonpulse", "toxic", "flamecharge", "stoneedge", "roost"],
		randomDoubleBattleMoves: ["blueflare", "dracometeor", "dragonpulse", "heatwave", "flamecharge", "roost", "protect", "tailwind"],
		tier: "Uber",
		doublesTier: "DUber",
	},
	zekrom: {
		randomBattleMoves: ["boltstrike", "outrage", "dragonclaw", "dracometeor", "voltswitch", "honeclaws", "substitute", "roost"],
		randomDoubleBattleMoves: ["protect", "dragonclaw", "boltstrike", "honeclaws", "dracometeor", "roost", "tailwind"],
		tier: "Uber",
		doublesTier: "DUber",
	},
	landorus: {
		randomBattleMoves: ["calmmind", "rockpolish", "earthpower", "focusblast", "psychic", "sludgewave", "stealthrock", "knockoff", "rockslide"],
		randomDoubleBattleMoves: ["earthpower", "focusblast", "hiddenpowerice", "psychic", "sludgebomb", "rockslide", "protect"],
		tier: "Uber",
		doublesTier: "DUU",
	},
	landorustherian: {
		randomBattleMoves: ["swordsdance", "rockpolish", "earthquake", "stoneedge", "uturn", "superpower", "stealthrock", "fly"],
		randomDoubleBattleMoves: ["rockslide", "earthquake", "stoneedge", "uturn", "superpower", "knockoff", "swordsdance", "fly", "protect"],
		tier: "OU",
		doublesTier: "DOU",
	},
	kyurem: {
		randomBattleMoves: ["dracometeor", "icebeam", "earthpower", "outrage", "substitute", "focusblast", "roost"],
		randomDoubleBattleMoves: ["icebeam", "dracometeor", "dragonpulse", "glaciate", "earthpower", "roost", "protect"],
		tier: "RUBL",
		doublesTier: "(DUU)",
	},
	kyuremblack: {
		randomBattleMoves: ["outrage", "fusionbolt", "icebeam", "roost", "substitute", "earthpower", "dragonclaw"],
		randomDoubleBattleMoves: ["protect", "fusionbolt", "icebeam", "roost", "earthpower", "dragonclaw"],
		tier: "OU",
		doublesTier: "DOU",
	},
	kyuremwhite: {
		randomBattleMoves: ["dracometeor", "icebeam", "fusionflare", "earthpower", "focusblast", "dragonpulse", "substitute", "roost", "toxic"],
		randomDoubleBattleMoves: ["dracometeor", "dragonpulse", "icebeam", "fusionflare", "earthpower", "roost", "protect"],
		tier: "Uber",
		doublesTier: "DUber",
	},
	keldeo: {
		randomBattleMoves: ["hydropump", "secretsword", "calmmind", "hiddenpowerflying", "hiddenpowerelectric", "substitute", "scald", "icywind"],
		randomDoubleBattleMoves: ["hydropump", "secretsword", "protect", "hiddenpowerflying", "hiddenpowerelectric", "icywind", "calmmind", "taunt"],
		tier: "OU",
		doublesTier: "(DUU)",
	},
	keldeoresolute: {
		tier: "OU",
		doublesTier: "(DUU)",
	},
	meloetta: {
		randomBattleMoves: ["uturn", "calmmind", "psyshock", "hypervoice", "shadowball", "focusblast"],
		randomDoubleBattleMoves: ["calmmind", "psyshock", "hypervoice", "shadowball", "focusblast", "protect"],
		tier: "RUBL",
		doublesTier: "(DUU)",
	},
	meloettapirouette: {
		randomBattleMoves: ["relicsong", "closecombat", "knockoff", "return"],
		randomDoubleBattleMoves: ["relicsong", "closecombat", "knockoff", "return", "protect"],
	},
	genesect: {
		randomBattleMoves: ["technoblast", "uturn", "icebeam", "flamethrower", "thunderbolt", "ironhead", "shiftgear", "extremespeed", "blazekick"],
		randomDoubleBattleMoves: ["uturn", "bugbuzz", "icebeam", "flamethrower", "thunderbolt", "ironhead", "extremespeed", "protect", "technoblast"],
		tier: "Uber",
		doublesTier: "DOU",
	},
	genesectburn: {
		tier: "Uber",
		doublesTier: "(DOU)",
	},
	genesectchill: {
		tier: "Uber",
		doublesTier: "(DOU)",
	},
	genesectdouse: {
		tier: "Uber",
		doublesTier: "(DOU)",
	},
	genesectshock: {
		tier: "Uber",
		doublesTier: "(DOU)",
	},
	chespin: {
		tier: "LC",
	},
	quilladin: {
		tier: "NFE",
	},
	chesnaught: {
		randomBattleMoves: ["leechseed", "synthesis", "spikes", "drainpunch", "spikyshield", "woodhammer"],
		randomDoubleBattleMoves: ["leechseed", "hammerarm", "spikyshield", "stoneedge", "woodhammer", "rockslide"],
		tier: "UU",
		doublesTier: "(DUU)",
	},
	fennekin: {
		tier: "LC",
	},
	braixen: {
		tier: "NFE",
	},
	delphox: {
		randomBattleMoves: ["calmmind", "fireblast", "psyshock", "grassknot", "switcheroo", "shadowball"],
		randomDoubleBattleMoves: ["calmmind", "fireblast", "psyshock", "grassknot", "switcheroo", "heatwave", "protect"],
		tier: "NU",
		doublesTier: "(DUU)",
	},
	froakie: {
		tier: "LC",
	},
	frogadier: {
		tier: "NFE",
	},
	greninja: {
		randomBattleMoves: ["hydropump", "icebeam", "gunkshot", "uturn", "spikes", "toxicspikes", "taunt"],
		randomDoubleBattleMoves: ["hydropump", "uturn", "gunkshot", "icebeam", "matblock", "taunt", "darkpulse", "protect"],
		tier: "OU",
		doublesTier: "DUU",
	},
	greninjaash: {
		randomBattleMoves: ["hydropump", "icebeam", "darkpulse", "watershuriken", "uturn"],
		tier: "OU",
		doublesTier: "DUU",
	},
	bunnelby: {
		tier: "LC",
	},
	diggersby: {
		randomBattleMoves: ["earthquake", "return", "wildcharge", "uturn", "swordsdance", "quickattack", "knockoff", "agility"],
		randomDoubleBattleMoves: ["earthquake", "uturn", "return", "knockoff", "protect", "quickattack"],
		tier: "UUBL",
		doublesTier: "(DUU)",
	},
	fletchling: {
		tier: "LC",
	},
	fletchinder: {
		tier: "NFE",
	},
	talonflame: {
		randomBattleMoves: ["bravebird", "flareblitz", "roost", "swordsdance", "uturn", "willowisp", "overheat"],
		randomDoubleBattleMoves: ["bravebird", "flareblitz", "roost", "swordsdance", "uturn", "willowisp", "tailwind", "taunt", "protect"],
		tier: "RUBL",
		doublesTier: "DUU",
	},
	scatterbug: {
		tier: "LC",
	},
	spewpa: {
		tier: "NFE",
	},
	vivillon: {
		randomBattleMoves: ["sleeppowder", "quiverdance", "hurricane", "energyball", "substitute"],
		randomDoubleBattleMoves: ["sleeppowder", "quiverdance", "hurricane", "bugbuzz", "protect"],
		tier: "NU",
		doublesTier: "(DUU)",
	},
	vivillonfancy: {
		tier: "NU",
		doublesTier: "(DUU)",
	},
	vivillonpokeball: {
		tier: "NU",
		doublesTier: "(DUU)",
	},
	litleo: {
		tier: "LC",
	},
	pyroar: {
		randomBattleMoves: ["sunnyday", "fireblast", "hypervoice", "solarbeam", "willowisp", "darkpulse"],
		randomDoubleBattleMoves: ["hypervoice", "fireblast", "willowisp", "protect", "sunnyday", "solarbeam"],
		tier: "PUBL",
		doublesTier: "(DUU)",
	},
	flabebe: {
		tier: "LC",
	},
	floette: {
		tier: "NFE",
	},
	floetteeternal: {
		randomBattleMoves: ["lightofruin", "psychic", "hiddenpowerfire", "hiddenpowerground", "moonblast"],
		randomDoubleBattleMoves: ["lightofruin", "dazzlinggleam", "psychic", "protect", "hiddenpowerfire", "calmmind"],
		isNonstandard: "Unobtainable",
		tier: "Illegal",
	},
	florges: {
		randomBattleMoves: ["aromatherapy", "defog", "moonblast", "synthesis", "toxic", "wish"],
		randomDoubleBattleMoves: ["moonblast", "dazzlinggleam", "psychic", "protect", "calmmind", "defog", "helpinghand"],
		tier: "RU",
		doublesTier: "(DUU)",
	},
	skiddo: {
		tier: "LC",
	},
	gogoat: {
		randomBattleMoves: ["bulkup", "hornleech", "earthquake", "rockslide", "substitute", "leechseed", "milkdrink"],
		randomDoubleBattleMoves: ["hornleech", "earthquake", "brickbreak", "bulkup", "leechseed", "milkdrink", "rockslide", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	pancham: {
		tier: "LC",
	},
	pangoro: {
		randomBattleMoves: ["bulletpunch", "drainpunch", "icepunch", "knockoff", "superpower", "swordsdance"],
		randomDoubleBattleMoves: ["partingshot", "hammerarm", "knockoff", "icepunch", "gunkshot", "protect"],
		tier: "NU",
		doublesTier: "(DUU)",
	},
	furfrou: {
		randomBattleMoves: ["return", "cottonguard", "thunderwave", "substitute", "toxic", "suckerpunch", "uturn", "rest"],
		randomDoubleBattleMoves: ["return", "cottonguard", "uturn", "thunderwave", "snarl", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	espurr: {
		tier: "LC",
	},
	meowstic: {
		randomBattleMoves: ["toxic", "yawn", "thunderwave", "psychic", "reflect", "lightscreen", "healbell"],
		randomDoubleBattleMoves: ["fakeout", "thunderwave", "psychic", "reflect", "lightscreen", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	meowsticf: {
		randomBattleMoves: ["calmmind", "psychic", "psyshock", "shadowball", "energyball", "thunderbolt"],
		randomDoubleBattleMoves: ["psychic", "darkpulse", "fakeout", "energyball", "thunderbolt", "nastyplot", "protect", "helpinghand"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	honedge: {
		tier: "LC",
	},
	doublade: {
		randomBattleMoves: ["swordsdance", "shadowclaw", "shadowsneak", "ironhead", "sacredsword"],
		randomDoubleBattleMoves: ["swordsdance", "shadowclaw", "shadowsneak", "ironhead", "sacredsword", "protect"],
		tier: "UU",
		doublesTier: "NFE",
	},
	aegislash: {
		randomBattleMoves: ["flashcannon", "hiddenpowerice", "kingsshield", "shadowball", "shadowsneak"],
		randomDoubleBattleMoves: ["flashcannon", "hiddenpowerice", "kingsshield", "shadowball", "shadowsneak"],
		tier: "Uber",
		doublesTier: "DOU",
	},
	aegislashblade: {
		randomBattleMoves: ["ironhead", "sacredsword", "shadowclaw", "shadowsneak", "swordsdance"],
		randomDoubleBattleMoves: ["ironhead", "kingsshield", "sacredsword", "shadowclaw", "shadowsneak", "swordsdance"],
	},
	spritzee: {
		tier: "LC",
	},
	aromatisse: {
		randomBattleMoves: ["calmmind", "moonblast", "rest", "sleeptalk", "toxic"],
		randomDoubleBattleMoves: ["moonblast", "trickroom", "thunderbolt", "protect", "healpulse"],
		tier: "PUBL",
		doublesTier: "(DUU)",
	},
	swirlix: {
		tier: "LC Uber",
	},
	slurpuff: {
		randomBattleMoves: ["bellydrum", "playrough", "return", "drainpunch"],
		randomDoubleBattleMoves: ["bellydrum", "playrough", "return", "drainpunch", "protect"],
		tier: "NUBL",
		doublesTier: "(DUU)",
	},
	inkay: {
		tier: "LC",
	},
	malamar: {
		randomBattleMoves: ["superpower", "knockoff", "psychocut", "rest", "sleeptalk", "happyhour"],
		randomDoubleBattleMoves: ["superpower", "psychocut", "rockslide", "trickroom", "knockoff", "protect"],
		tier: "NU",
		doublesTier: "(DUU)",
	},
	binacle: {
		tier: "LC",
	},
	barbaracle: {
		randomBattleMoves: ["earthquake", "liquidation", "lowkick", "shellsmash", "stoneedge"],
		randomDoubleBattleMoves: ["shellsmash", "liquidation", "crosschop", "rockslide", "protect"],
		tier: "NUBL",
		doublesTier: "(DUU)",
	},
	skrelp: {
		tier: "LC",
	},
	dragalge: {
		randomBattleMoves: ["dracometeor", "sludgewave", "focusblast", "scald", "hiddenpowerfire", "toxicspikes", "dragonpulse"],
		randomDoubleBattleMoves: ["dracometeor", "sludgebomb", "focusblast", "scald", "hiddenpowerfire", "protect", "dragonpulse"],
		tier: "RU",
		doublesTier: "(DUU)",
	},
	clauncher: {
		tier: "LC",
	},
	clawitzer: {
		randomBattleMoves: ["scald", "waterpulse", "darkpulse", "aurasphere", "icebeam", "uturn"],
		randomDoubleBattleMoves: ["waterpulse", "icebeam", "uturn", "darkpulse", "aurasphere", "muddywater", "helpinghand", "protect"],
		tier: "NU",
		doublesTier: "(DUU)",
	},
	helioptile: {
		tier: "LC",
	},
	heliolisk: {
		randomBattleMoves: ["raindance", "hypervoice", "surf", "darkpulse", "hiddenpowerice", "voltswitch", "thunderbolt"],
		randomDoubleBattleMoves: ["grassknot", "voltswitch", "darkpulse", "thunderbolt", "hypervoice", "protect"],
		tier: "NU",
		doublesTier: "(DUU)",
	},
	tyrunt: {
		tier: "LC",
	},
	tyrantrum: {
		randomBattleMoves: ["stealthrock", "dragondance", "dragonclaw", "earthquake", "superpower", "outrage", "headsmash"],
		randomDoubleBattleMoves: ["rockslide", "dragondance", "headsmash", "dragonclaw", "earthquake", "protect"],
		tier: "RU",
		doublesTier: "(DUU)",
	},
	amaura: {
		tier: "LC",
	},
	aurorus: {
		randomBattleMoves: ["ancientpower", "blizzard", "thunderwave", "earthpower", "freezedry", "hypervoice", "stealthrock"],
		randomDoubleBattleMoves: ["hypervoice", "ancientpower", "thunderwave", "earthpower", "freezedry", "icywind", "protect"],
		tier: "PU",
		doublesTier: "(DUU)",
	},
	sylveon: {
		randomBattleMoves: ["hypervoice", "calmmind", "psyshock", "hiddenpowerfire", "wish", "protect"],
		randomDoubleBattleMoves: ["hypervoice", "protect", "psyshock", "helpinghand", "shadowball", "hiddenpowerground"],
		tier: "UU",
		doublesTier: "DUU",
	},
	hawlucha: {
		randomBattleMoves: ["acrobatics", "highjumpkick", "skyattack", "substitute", "swordsdance"],
		randomDoubleBattleMoves: ["swordsdance", "highjumpkick", "acrobatics", "encore", "protect"],
		tier: "OU",
		doublesTier: "(DUU)",
	},
	dedenne: {
		randomBattleMoves: ["substitute", "recycle", "thunderbolt", "nuzzle", "grassknot", "hiddenpowerice", "toxic"],
		randomDoubleBattleMoves: ["eerieimpulse", "helpinghand", "nuzzle", "recycle", "superfang", "thunderbolt"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	carbink: {
		randomBattleMoves: ["stealthrock", "lightscreen", "reflect", "explosion", "powergem", "moonblast"],
		randomDoubleBattleMoves: ["trickroom", "lightscreen", "reflect", "explosion", "stealthrock", "moonblast", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	goomy: {
		tier: "LC",
	},
	sliggoo: {
		tier: "NFE",
	},
	goodra: {
		randomBattleMoves: ["dracometeor", "dragonpulse", "fireblast", "sludgebomb", "thunderbolt", "earthquake", "dragontail"],
		randomDoubleBattleMoves: ["thunderbolt", "dragonpulse", "fireblast", "muddywater", "dracometeor", "powerwhip", "protect"],
		tier: "RU",
		doublesTier: "(DUU)",
	},
	klefki: {
		randomBattleMoves: ["dazzlinggleam", "foulplay", "magnetrise", "spikes", "thunderwave", "toxic"],
		randomDoubleBattleMoves: ["reflect", "lightscreen", "playrough", "thunderwave", "protect", "dazzlinggleam", "foulplay"],
		tier: "UU",
		doublesTier: "(DUU)",
	},
	phantump: {
		tier: "LC",
	},
	trevenant: {
		randomBattleMoves: ["hornleech", "shadowclaw", "earthquake", "rockslide", "woodhammer", "trickroom"],
		randomDoubleBattleMoves: ["hornleech", "woodhammer", "leechseed", "shadowclaw", "willowisp", "trickroom", "rockslide", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	pumpkaboo: {
		tier: "LC",
	},
	pumpkaboosmall: {
		tier: "LC",
	},
	pumpkaboolarge: {
		tier: "LC",
	},
	pumpkaboosuper: {
		tier: "LC",
	},
	gourgeist: {
		randomBattleMoves: ["willowisp", "seedbomb", "leechseed", "shadowsneak", "substitute", "synthesis"],
		randomDoubleBattleMoves: ["willowisp", "shadowsneak", "seedbomb", "leechseed", "phantomforce", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	gourgeistsmall: {
		randomBattleMoves: ["willowisp", "seedbomb", "leechseed", "shadowsneak", "substitute", "synthesis"],
		randomDoubleBattleMoves: ["willowisp", "shadowsneak", "seedbomb", "leechseed", "phantomforce", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	gourgeistlarge: {
		randomBattleMoves: ["willowisp", "seedbomb", "leechseed", "shadowsneak", "substitute", "synthesis"],
		randomDoubleBattleMoves: ["willowisp", "shadowsneak", "seedbomb", "leechseed", "phantomforce", "protect", "trickroom"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	gourgeistsuper: {
		randomBattleMoves: ["willowisp", "seedbomb", "leechseed", "shadowsneak", "substitute", "synthesis"],
		randomDoubleBattleMoves: ["willowisp", "shadowsneak", "seedbomb", "leechseed", "phantomforce", "protect", "trickroom"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	bergmite: {
		tier: "LC",
	},
	avalugg: {
		randomBattleMoves: ["avalanche", "recover", "toxic", "rapidspin", "roar", "earthquake"],
		randomDoubleBattleMoves: ["avalanche", "recover", "earthquake", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	noibat: {
		tier: "LC",
	},
	noivern: {
		randomBattleMoves: ["dracometeor", "hurricane", "flamethrower", "boomburst", "switcheroo", "uturn", "roost", "taunt"],
		randomDoubleBattleMoves: ["hurricane", "dracometeor", "flamethrower", "uturn", "switcheroo", "tailwind", "taunt", "protect"],
		tier: "RU",
		doublesTier: "(DUU)",
	},
	xerneas: {
		randomBattleMoves: ["geomancy", "moonblast", "focusblast", "thunderbolt", "hiddenpowerfire", "psyshock", "rockslide", "closecombat"],
		randomDoubleBattleMoves: ["geomancy", "dazzlinggleam", "focusblast", "thunderbolt", "hiddenpowerfire", "psyshock", "rockslide", "closecombat", "protect"],
		tier: "Uber",
		doublesTier: "DUber",
	},
	yveltal: {
		randomBattleMoves: ["darkpulse", "oblivionwing", "focusblast", "uturn", "foulplay", "suckerpunch", "toxic", "taunt", "roost"],
		randomDoubleBattleMoves: ["darkpulse", "oblivionwing", "taunt", "heatwave", "roost", "suckerpunch", "snarl", "skydrop", "protect"],
		tier: "Uber",
		doublesTier: "DUber",
	},
	zygarde: {
		randomBattleMoves: ["dragondance", "extremespeed", "outrage", "substitute", "thousandarrows"],
		randomDoubleBattleMoves: ["dragondance", "thousandarrows", "extremespeed", "rockslide", "coil", "stoneedge", "glare", "protect"],
		tier: "Uber",
		doublesTier: "DOU",
	},
	zygarde10: {
		randomBattleMoves: ["coil", "extremespeed", "irontail", "outrage", "thousandarrows"],
		randomDoubleBattleMoves: ["dragondance", "thousandarrows", "extremespeed", "irontail", "protect"],
		tier: "RU",
		doublesTier: "(DUU)",
	},
	zygardecomplete: {
		tier: "Uber",
		doublesTier: "DUber",
	},
	diancie: {
		randomBattleMoves: ["reflect", "lightscreen", "stealthrock", "diamondstorm", "moonblast", "hiddenpowerfire"],
		randomDoubleBattleMoves: ["diamondstorm", "moonblast", "calmmind", "earthpower", "dazzlinggleam", "protect"],
		tier: "RU",
		doublesTier: "DOU",
	},
	dianciemega: {
		randomBattleMoves: ["calmmind", "moonblast", "earthpower", "hiddenpowerfire", "diamondstorm"],
		randomDoubleBattleMoves: ["diamondstorm", "moonblast", "calmmind", "psyshock", "earthpower", "hiddenpowerfire", "dazzlinggleam", "protect"],
		tier: "OU",
		doublesTier: "DOU",
	},
	hoopa: {
		randomBattleMoves: ["nastyplot", "psyshock", "shadowball", "focusblast", "trick"],
		randomDoubleBattleMoves: ["hyperspacehole", "shadowball", "focusblast", "protect", "trickroom"],
		tier: "RU",
		doublesTier: "(DUU)",
	},
	hoopaunbound: {
		randomBattleMoves: ["nastyplot", "substitute", "psychic", "darkpulse", "focusblast", "hyperspacefury", "zenheadbutt", "icepunch", "drainpunch", "gunkshot", "trick"],
		randomDoubleBattleMoves: ["psychic", "darkpulse", "focusblast", "protect", "hyperspacefury", "zenheadbutt", "icepunch", "drainpunch", "gunkshot"],
		tier: "UUBL",
		doublesTier: "DOU",
	},
	volcanion: {
		randomBattleMoves: ["substitute", "steameruption", "fireblast", "sludgebomb", "earthpower", "superpower"],
		randomDoubleBattleMoves: ["steameruption", "heatwave", "sludgebomb", "earthpower", "protect"],
		tier: "UU",
		doublesTier: "DOU",
	},
	rowlet: {
		tier: "LC",
	},
	dartrix: {
		tier: "NFE",
	},
	decidueye: {
		randomBattleMoves: ["spiritshackle", "uturn", "leafblade", "roost", "swordsdance", "suckerpunch"],
		randomDoubleBattleMoves: ["spiritshackle", "leafblade", "bravebird", "protect", "suckerpunch"],
		tier: "NU",
		doublesTier: "(DUU)",
	},
	litten: {
		tier: "LC",
	},
	torracat: {
		tier: "NFE",
	},
	incineroar: {
		randomBattleMoves: ["fakeout", "darkestlariat", "flareblitz", "uturn", "earthquake", "knockoff"],
		randomDoubleBattleMoves: ["fakeout", "knockoff", "flareblitz", "willowisp", "taunt", "snarl", "uturn"],
		tier: "NU",
		doublesTier: "DOU",
	},
	popplio: {
		tier: "LC",
	},
	brionne: {
		tier: "NFE",
	},
	primarina: {
		randomBattleMoves: ["hydropump", "moonblast", "scald", "psychic", "hiddenpowerfire"],
		randomDoubleBattleMoves: ["hypervoice", "moonblast", "protect", "psychic", "icebeam"],
		tier: "UU",
		doublesTier: "(DUU)",
	},
	pikipek: {
		tier: "LC",
	},
	trumbeak: {
		tier: "NFE",
	},
	toucannon: {
		randomBattleMoves: ["boomburst", "beakblast", "roost", "brickbreak", "bulletseed"],
		randomDoubleBattleMoves: ["bulletseed", "rockblast", "beakblast", "tailwind", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	yungoos: {
		tier: "LC",
	},
	gumshoos: {
		randomBattleMoves: ["uturn", "return", "crunch", "earthquake", "firepunch"],
		randomDoubleBattleMoves: ["uturn", "return", "superfang", "protect", "crunch"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	gumshoostotem: {
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	grubbin: {
		tier: "LC",
	},
	charjabug: {
		tier: "NFE",
	},
	vikavolt: {
		randomBattleMoves: ["agility", "bugbuzz", "thunderbolt", "voltswitch", "energyball", "hiddenpowerice"],
		randomDoubleBattleMoves: ["thunderbolt", "bugbuzz", "stringshot", "protect", "voltswitch", "hiddenpowerice"],
		tier: "NU",
		doublesTier: "DUU",
	},
	vikavolttotem: {
		tier: "NU",
		doublesTier: "DUU",
	},
	crabrawler: {
		tier: "LC",
	},
	crabominable: {
		randomBattleMoves: ["icehammer", "closecombat", "earthquake", "stoneedge"],
		randomDoubleBattleMoves: ["icehammer", "closecombat", "stoneedge", "protect", "wideguard", "earthquake"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	oricorio: {
		randomBattleMoves: ["calmmind", "revelationdance", "hurricane", "toxic", "roost", "uturn"],
		randomDoubleBattleMoves: ["revelationdance", "airslash", "hurricane", "tailwind", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	oricoriopompom: {
		randomBattleMoves: ["calmmind", "revelationdance", "hurricane", "toxic", "roost", "uturn"],
		randomDoubleBattleMoves: ["revelationdance", "airslash", "hurricane", "tailwind", "protect"],
		tier: "PU",
		doublesTier: "(DUU)",
	},
	oricoriopau: {
		randomBattleMoves: ["calmmind", "revelationdance", "hurricane", "toxic", "roost", "uturn"],
		randomDoubleBattleMoves: ["revelationdance", "airslash", "hurricane", "tailwind", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	oricoriosensu: {
		randomBattleMoves: ["calmmind", "revelationdance", "hurricane", "toxic", "roost", "uturn"],
		randomDoubleBattleMoves: ["revelationdance", "airslash", "hurricane", "tailwind", "protect"],
		tier: "PU",
		doublesTier: "(DUU)",
	},
	cutiefly: {
		tier: "LC Uber",
	},
	ribombee: {
		randomBattleMoves: ["quiverdance", "bugbuzz", "moonblast", "hiddenpowerfire", "roost"],
		randomDoubleBattleMoves: ["quiverdance", "pollenpuff", "moonblast", "protect", "stickyweb"],
		tier: "RU",
		doublesTier: "(DUU)",
	},
	ribombeetotem: {
		tier: "RU",
		doublesTier: "(DUU)",
	},
	rockruff: {
		tier: "LC",
	},
	rockruffdusk: {
		tier: "LC",
	},
	lycanroc: {
		randomBattleMoves: ["swordsdance", "accelerock", "stoneedge", "drillrun", "firefang"],
		randomDoubleBattleMoves: ["accelerock", "stoneedge", "crunch", "firefang", "protect", "taunt"],
		tier: "PU",
		doublesTier: "(DUU)",
	},
	lycanrocmidnight: {
		randomBattleMoves: ["stoneedge", "stealthrock", "suckerpunch", "swordsdance", "firepunch"],
		randomDoubleBattleMoves: ["stoneedge", "suckerpunch", "swordsdance", "protect", "taunt"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	lycanrocdusk: {
		randomBattleMoves: ["swordsdance", "accelerock", "stoneedge", "drillrun", "firefang", "return"],
		randomDoubleBattleMoves: ["accelerock", "stoneedge", "rockslide", "drillrun", "firefang", "protect"],
		tier: "RU",
		doublesTier: "(DUU)",
	},
	wishiwashi: {
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	wishiwashischool: {
		randomBattleMoves: ["scald", "hydropump", "icebeam", "hiddenpowergrass", "earthquake"],
		randomDoubleBattleMoves: ["hydropump", "icebeam", "endeavor", "protect", "hiddenpowergrass", "earthquake", "helpinghand"],
	},
	mareanie: {
		tier: "LC",
	},
	toxapex: {
		randomBattleMoves: ["toxicspikes", "banefulbunker", "recover", "scald", "haze"],
		randomDoubleBattleMoves: ["scald", "banefulbunker", "haze", "wideguard", "toxicspikes", "recover"],
		tier: "OU",
		doublesTier: "(DUU)",
	},
	mudbray: {
		tier: "LC",
	},
	mudsdale: {
		randomBattleMoves: ["earthquake", "closecombat", "rockslide", "heavyslam", "stealthrock"],
		randomDoubleBattleMoves: ["highhorsepower", "heavyslam", "closecombat", "rockslide", "protect"],
		tier: "PU",
		doublesTier: "(DUU)",
	},
	dewpider: {
		tier: "LC",
	},
	araquanid: {
		randomBattleMoves: ["liquidation", "lunge", "toxic", "mirrorcoat", "stickyweb"],
		randomDoubleBattleMoves: ["liquidation", "lunge", "stickyweb", "protect", "wideguard"],
		tier: "RU",
		doublesTier: "DUU",
	},
	araquanidtotem: {
		tier: "RU",
		doublesTier: "DUU",
	},
	fomantis: {
		tier: "LC",
	},
	lurantis: {
		randomBattleMoves: ["leafstorm", "hiddenpowerice", "superpower", "knockoff", "synthesis"],
		randomDoubleBattleMoves: ["leafstorm", "superpower", "hiddenpowerice", "knockoff", "protect"],
		tier: "PU",
		doublesTier: "(DUU)",
	},
	lurantistotem: {
		tier: "PU",
		doublesTier: "(DUU)",
	},
	morelull: {
		tier: "LC",
	},
	shiinotic: {
		randomBattleMoves: ["spore", "strengthsap", "moonblast", "substitute", "leechseed"],
		randomDoubleBattleMoves: ["spore", "gigadrain", "moonblast", "strengthsap", "leechseed", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	salandit: {
		tier: "LC",
	},
	salazzle: {
		randomBattleMoves: ["nastyplot", "fireblast", "sludgewave", "hiddenpowergrass"],
		randomDoubleBattleMoves: ["protect", "flamethrower", "sludgebomb", "hiddenpowerground", "hiddenpowergrass", "fakeout", "encore", "taunt"],
		tier: "RU",
		doublesTier: "(DUU)",
	},
	salazzletotem: {
		tier: "RU",
		doublesTier: "(DUU)",
	},
	stufful: {
		tier: "LC",
	},
	bewear: {
		randomBattleMoves: ["hammerarm", "icepunch", "swordsdance", "return", "shadowclaw", "doubleedge"],
		randomDoubleBattleMoves: ["hammerarm", "icepunch", "doubleedge", "protect", "wideguard"],
		tier: "RU",
		doublesTier: "(DUU)",
	},
	bounsweet: {
		tier: "LC",
	},
	steenee: {
		tier: "NFE",
	},
	tsareena: {
		randomBattleMoves: ["powerwhip", "highjumpkick", "knockoff", "uturn", "rapidspin", "synthesis"],
		randomDoubleBattleMoves: ["playrough", "powerwhip", "uturn", "feint", "protect", "knockoff"],
		tier: "RU",
		doublesTier: "DUU",
	},
	comfey: {
		randomBattleMoves: ["aromatherapy", "drainingkiss", "toxic", "synthesis", "uturn"],
		randomDoubleBattleMoves: ["floralhealing", "drainingkiss", "uturn", "toxic", "taunt"],
		tier: "NU",
		doublesTier: "(DUU)",
	},
	oranguru: {
		randomBattleMoves: ["nastyplot", "psyshock", "focusblast", "thunderbolt", "trickroom"],
		randomDoubleBattleMoves: ["trickroom", "foulplay", "instruct", "psychic", "protect"],
		tier: "(PU)",
		doublesTier: "DUU",
	},
	passimian: {
		randomBattleMoves: ["rockslide", "closecombat", "earthquake", "ironhead", "uturn", "knockoff"],
		randomDoubleBattleMoves: ["closecombat", "uturn", "knockoff", "protect", "rockslide", "taunt"],
		tier: "NU",
		doublesTier: "(DUU)",
	},
	wimpod: {
		tier: "LC",
	},
	golisopod: {
		randomBattleMoves: ["spikes", "firstimpression", "liquidation", "aquajet", "knockoff"],
		randomDoubleBattleMoves: ["firstimpression", "aquajet", "liquidation", "leechlife", "protect", "wideguard"],
		tier: "RU",
		doublesTier: "(DUU)",
	},
	sandygast: {
		tier: "LC",
	},
	palossand: {
		randomBattleMoves: ["earthpower", "shadowball", "shoreup", "stealthrock", "toxic"],
		randomDoubleBattleMoves: ["shoreup", "protect", "shadowball", "earthpower", "stealthrock", "toxic"],
		tier: "NU",
		doublesTier: "(DUU)",
	},
	pyukumuku: {
		randomBattleMoves: ["block", "counter", "lightscreen", "recover", "toxic"],
		randomDoubleBattleMoves: ["reflect", "lightscreen", "counter", "helpinghand", "memento"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	typenull: {
		randomBattleMoves: ["return", "uturn", "swordsdance", "rest", "sleeptalk"],
		tier: "(PU)",
		doublesTier: "NFE",
	},
	silvally: {
		randomBattleMoves: ["swordsdance", "return", "doubleedge", "crunch", "flamecharge", "flamethrower", "icebeam", "uturn", "ironhead"],
		randomDoubleBattleMoves: ["protect", "doubleedge", "uturn", "crunch", "icebeam", "partingshot", "flamecharge", "swordsdance", "explosion"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	silvallybug: {
		randomBattleMoves: ["flamethrower", "icebeam", "thunderbolt", "uturn", "defog"],
		randomDoubleBattleMoves: ["protect", "uturn", "flamethrower", "icebeam", "thunderbolt", "thunderwave"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	silvallydark: {
		randomBattleMoves: ["multiattack", "swordsdance", "flamecharge", "ironhead"],
		randomDoubleBattleMoves: ["protect", "multiattack", "icebeam", "partingshot", "uturn", "snarl", "thunderwave"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	silvallydragon: {
		randomBattleMoves: ["multiattack", "ironhead", "flamecharge", "flamethrower", "icebeam", "dracometeor", "swordsdance", "uturn"],
		randomDoubleBattleMoves: ["protect", "multiattack", "icebeam", "flamethrower", "partingshot", "uturn", "thunderwave"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	silvallyelectric: {
		randomBattleMoves: ["multiattack", "flamethrower", "icebeam", "partingshot", "toxic"],
		randomDoubleBattleMoves: ["protect", "thunderbolt", "icebeam", "uturn", "partingshot", "snarl", "thunderwave"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	silvallyfairy: {
		randomBattleMoves: ["multiattack", "flamethrower", "rockslide", "thunderwave", "partingshot"],
		randomDoubleBattleMoves: ["protect", "multiattack", "uturn", "icebeam", "partingshot", "flamethrower", "thunderwave"],
		tier: "PU",
		doublesTier: "(DUU)",
	},
	silvallyfighting: {
		randomBattleMoves: ["swordsdance", "multiattack", "shadowclaw", "flamecharge", "ironhead"],
		randomDoubleBattleMoves: ["protect", "multiattack", "rockslide", "swordsdance", "flamecharge"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	silvallyfire: {
		randomBattleMoves: ["multiattack", "icebeam", "thunderbolt", "uturn", "defog"],
		randomDoubleBattleMoves: ["protect", "flamethrower", "snarl", "uturn", "thunderbolt", "icebeam", "thunderwave"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	silvallyflying: {
		randomBattleMoves: ["multiattack", "flamethrower", "ironhead", "partingshot", "thunderwave"],
		randomDoubleBattleMoves: ["protect", "multiattack", "partingshot", "swordsdance", "flamecharge", "uturn", "ironhead", "thunderwave"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	silvallyghost: {
		randomBattleMoves: ["multiattack", "flamethrower", "icebeam", "partingshot", "toxic"],
		randomDoubleBattleMoves: ["protect", "multiattack", "uturn", "icebeam", "partingshot"],
		tier: "PU",
		doublesTier: "(DUU)",
	},
	silvallygrass: {
		randomBattleMoves: ["multiattack", "flamethrower", "icebeam", "partingshot", "toxic"],
		randomDoubleBattleMoves: ["protect", "flamethrower", "multiattack", "icebeam", "uturn", "partingshot", "thunderwave"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	silvallyground: {
		randomBattleMoves: ["multiattack", "swordsdance", "flamecharge", "rockslide"],
		randomDoubleBattleMoves: ["protect", "multiattack", "icebeam", "thunderbolt", "flamecharge", "rockslide", "swordsdance"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	silvallyice: {
		randomBattleMoves: ["multiattack", "thunderbolt", "flamethrower", "uturn", "toxic"],
		randomDoubleBattleMoves: ["protect", "icebeam", "thunderbolt", "partingshot", "uturn", "thunderwave"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	silvallypoison: {
		randomBattleMoves: ["multiattack", "flamethrower", "icebeam", "partingshot", "toxic"],
		randomDoubleBattleMoves: ["protect", "multiattack", "uturn", "partingshot", "flamethrower", "icebeam", "thunderwave"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	silvallypsychic: {
		randomBattleMoves: ["multiattack", "flamethrower", "rockslide", "partingshot", "thunderwave"],
		randomDoubleBattleMoves: ["protect", "multiattack", "partingshot", "uturn", "flamethrower", "thunderwave"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	silvallyrock: {
		randomBattleMoves: ["multiattack", "flamethrower", "icebeam", "partingshot", "toxic"],
		randomDoubleBattleMoves: ["protect", "rockslide", "uturn", "icebeam", "flamethrower", "partingshot"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	silvallysteel: {
		randomBattleMoves: ["multiattack", "crunch", "flamethrower", "thunderbolt", "defog"],
		randomDoubleBattleMoves: ["protect", "multiattack", "swordsdance", "rockslide", "flamecharge", "uturn", "partingshot"],
		tier: "NU",
		doublesTier: "(DUU)",
	},
	silvallywater: {
		randomBattleMoves: ["multiattack", "icebeam", "thunderbolt", "partingshot", "defog"],
		randomDoubleBattleMoves: ["protect", "multiattack", "icebeam", "thunderbolt", "flamethrower", "partingshot", "uturn", "thunderwave"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	minior: {
		randomBattleMoves: ["shellsmash", "powergem", "acrobatics", "earthquake"],
		randomDoubleBattleMoves: ["shellsmash", "powergem", "acrobatics", "earthquake", "protect"],
		tier: "NU",
		doublesTier: "(DUU)",
	},
	miniormeteor: {},
	komala: {
		randomBattleMoves: ["return", "suckerpunch", "woodhammer", "earthquake", "playrough", "uturn"],
		randomDoubleBattleMoves: ["protect", "return", "uturn", "suckerpunch", "woodhammer", "shadowclaw", "playrough", "swordsdance"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	turtonator: {
		randomBattleMoves: ["fireblast", "shellsmash", "earthquake", "dragontail", "explosion", "dragonpulse", "dracometeor"],
		randomDoubleBattleMoves: ["dragonpulse", "dracometeor", "fireblast", "shellsmash", "protect"],
		tier: "(PU)",
		doublesTier: "(DUU)",
	},
	togedemaru: {
		randomBattleMoves: ["ironhead", "spikyshield", "zingzap", "nuzzle", "uturn", "wish"],
		randomDoubleBattleMoves: ["ironhead", "zingzap", "nuzzle", "spikyshield", "encore", "fakeout", "uturn"],
		tier: "NU",
		doublesTier: "DUU",
	},
	togedemarutotem: {
		tier: "NU",
		doublesTier: "DUU",
	},
	mimikyu: {
		randomBattleMoves: ["swordsdance", "shadowsneak", "playrough", "taunt", "shadowclaw"],
		randomDoubleBattleMoves: ["shadowclaw", "playrough", "willowisp", "shadowsneak", "swordsdance", "protect"],
		tier: "UU",
		doublesTier: "DUU",
	},
	mimikyutotem: {
		tier: "UU",
		doublesTier: "DUU",
	},
	mimikyubustedtotem: {},
	bruxish: {
		randomBattleMoves: ["psychicfangs", "crunch", "liquidation", "icefang", "aquajet", "swordsdance"],
		randomDoubleBattleMoves: ["psychicfangs", "crunch", "liquidation", "aquajet", "protect", "swordsdance"],
		tier: "NUBL",
		doublesTier: "DUU",
	},
	drampa: {
		randomBattleMoves: ["dracometeor", "dragonpulse", "hypervoice", "fireblast", "thunderbolt", "glare", "roost"],
		randomDoubleBattleMoves: ["dracometeor", "dragonpulse", "hypervoice", "fireblast", "protect", "glare", "roost"],
		tier: "PU",
		doublesTier: "(DUU)",
	},
	dhelmise: {
		randomBattleMoves: ["powerwhip", "anchorshot", "knockoff", "earthquake", "rapidspin", "synthesis"],
		randomDoubleBattleMoves: ["powerwhip", "knockoff", "anchorshot", "protect", "rapidspin"],
		tier: "NU",
		doublesTier: "(DUU)",
	},
	jangmoo: {
		tier: "LC",
	},
	hakamoo: {
		tier: "NFE",
	},
	kommoo: {
		randomBattleMoves: ["dragondance", "outrage", "closecombat", "poisonjab", "clangingscales"],
		randomDoubleBattleMoves: ["clangingscales", "closecombat", "dragondance", "poisonjab"],
		tier: "OU",
		doublesTier: "DOU",
	},
	kommoototem: {
		tier: "OU",
		doublesTier: "DOU",
	},
	tapukoko: {
		randomBattleMoves: ["thunderbolt", "dazzlinggleam", "naturesmadness", "bravebird", "uturn", "defog"],
		randomDoubleBattleMoves: ["dazzlinggleam", "protect", "thunderbolt", "hiddenpowerice", "taunt", "skydrop", "naturesmadness", "uturn"],
		tier: "OU",
		doublesTier: "DOU",
	},
	tapulele: {
		randomBattleMoves: ["moonblast", "psychic", "psyshock", "calmmind", "focusblast", "hiddenpowerfire", "taunt"],
		randomDoubleBattleMoves: ["moonblast", "psychic", "dazzlinggleam", "focusblast", "protect", "taunt"],
		tier: "OU",
		doublesTier: "DOU",
	},
	tapubulu: {
		randomBattleMoves: ["woodhammer", "hornleech", "stoneedge", "superpower", "megahorn", "bulkup"],
		randomDoubleBattleMoves: ["woodhammer", "hornleech", "stoneedge", "superpower", "protect", "naturesmadness"],
		tier: "OU",
		doublesTier: "DOU",
	},
	tapufini: {
		randomBattleMoves: ["calmmind", "moonblast", "scald", "taunt", "icebeam", "hydropump"],
		randomDoubleBattleMoves: ["muddywater", "moonblast", "naturesmadness", "healpulse", "protect", "taunt", "swagger"],
		tier: "OU",
		doublesTier: "DOU",
	},
	cosmog: {
		tier: "LC",
	},
	cosmoem: {
		tier: "NFE",
	},
	solgaleo: {
		randomBattleMoves: ["sunsteelstrike", "zenheadbutt", "flareblitz", "morningsun", "stoneedge", "earthquake"],
		randomDoubleBattleMoves: ["wideguard", "protect", "sunsteelstrike", "morningsun", "zenheadbutt", "flareblitz"],
		tier: "Uber",
		doublesTier: "DUber",
	},
	lunala: {
		randomBattleMoves: ["moongeistbeam", "psyshock", "calmmind", "focusblast", "roost"],
		randomDoubleBattleMoves: ["wideguard", "protect", "roost", "moongeistbeam", "psychic", "moonblast"],
		tier: "Uber",
		doublesTier: "DUber",
	},
	nihilego: {
		randomBattleMoves: ["stealthrock", "toxicspikes", "sludgewave", "powergem", "thunderbolt", "grassknot"],
		randomDoubleBattleMoves: ["powergem", "sludgebomb", "grassknot", "protect", "thunderbolt", "hiddenpowerice"],
		tier: "UU",
		doublesTier: "(DUU)",
	},
	buzzwole: {
		randomBattleMoves: ["superpower", "drainpunch", "leechlife", "stoneedge", "poisonjab", "earthquake"],
		randomDoubleBattleMoves: ["drainpunch", "superpower", "leechlife", "icepunch", "poisonjab", "protect"],
		tier: "UUBL",
		doublesTier: "(DUU)",
	},
	pheromosa: {
		randomBattleMoves: ["highjumpkick", "icebeam", "poisonjab", "throatchop", "uturn"],
		randomDoubleBattleMoves: ["highjumpkick", "uturn", "icebeam", "poisonjab", "bugbuzz", "protect", "speedswap"],
		tier: "Uber",
		doublesTier: "DUU",
	},
	xurkitree: {
		randomBattleMoves: ["thunderbolt", "voltswitch", "energyball", "dazzlinggleam", "hiddenpowerice", "electricterrain"],
		randomDoubleBattleMoves: ["thunderbolt", "hiddenpowerice", "tailglow", "protect", "energyball", "hypnosis"],
		tier: "UUBL",
		doublesTier: "DUU",
	},
	celesteela: {
		randomBattleMoves: ["autotomize", "heavyslam", "airslash", "fireblast", "earthquake", "leechseed", "protect"],
		randomDoubleBattleMoves: ["protect", "heavyslam", "fireblast", "earthquake", "wideguard", "leechseed"],
		tier: "OU",
		doublesTier: "DOU",
	},
	kartana: {
		randomBattleMoves: ["leafblade", "sacredsword", "smartstrike", "knockoff", "swordsdance"],
		randomDoubleBattleMoves: ["leafblade", "sacredsword", "smartstrike", "swordsdance", "protect", "knockoff"],
		tier: "OU",
		doublesTier: "DOU",
	},
	guzzlord: {
		randomBattleMoves: ["dracometeor", "knockoff", "earthquake", "heavyslam", "fireblast"],
		randomDoubleBattleMoves: ["dracometeor", "knockoff", "wideguard", "fireblast", "protect"],
		tier: "PUBL",
		doublesTier: "(DUU)",
	},
	necrozma: {
		randomBattleMoves: ["calmmind", "photongeyser", "heatwave", "moonlight", "stealthrock"],
		randomDoubleBattleMoves: ["calmmind", "heatwave", "photongeyser", "moonlight", "earthpower"],
		tier: "RU",
		doublesTier: "(DUU)",
	},
	necrozmaduskmane: {
		randomBattleMoves: ["swordsdance", "sunsteelstrike", "photongeyser", "earthquake", "knockoff", "autotomize"],
		randomDoubleBattleMoves: ["swordsdance", "sunsteelstrike", "photongeyser", "earthquake", "knockoff", "rockslide"],
		tier: "Uber",
		doublesTier: "DUber",
	},
	necrozmadawnwings: {
		randomBattleMoves: ["calmmind", "moongeistbeam", "photongeyser", "heatwave", "powergem", "trickroom"],
		tier: "Uber",
		doublesTier: "DUber",
	},
	necrozmaultra: {
		tier: "Uber",
		doublesTier: "DUber",
	},
	magearna: {
		randomBattleMoves: ["shiftgear", "ironhead", "calmmind", "fleurcannon", "flashcannon", "thunderbolt", "focusblast"],
		randomDoubleBattleMoves: ["dazzlinggleam", "flashcannon", "protect", "trickroom", "fleurcannon", "aurasphere", "voltswitch"],
		tier: "OU",
		doublesTier: "DUber",
	},
	magearnaoriginal: {
		isNonstandard: "Unobtainable",
		tier: "Illegal",
	},
	marshadow: {
		randomBattleMoves: ["bulkup", "spectralthief", "closecombat", "rocktomb", "shadowsneak", "icepunch"],
		randomDoubleBattleMoves: ["bulkup", "spectralthief", "closecombat", "shadowsneak", "icepunch", "protect"],
		tier: "Uber",
		doublesTier: "DUber",
	},
	poipole: {
		tier: "NFE",
	},
	naganadel: {
		randomBattleMoves: ["nastyplot", "dragonpulse", "sludgewave", "fireblast", "dracometeor", "uturn"],
		randomDoubleBattleMoves: ["tailwind", "dragonpulse", "sludgebomb", "fireblast", "dracometeor", "uturn", "protect"],
		tier: "Uber",
		doublesTier: "DUU",
	},
	stakataka: {
		randomBattleMoves: ["gyroball", "stoneedge", "trickroom", "earthquake", "superpower", "stealthrock"],
		randomDoubleBattleMoves: ["gyroball", "stoneedge", "trickroom", "earthquake", "superpower", "stealthrock", "rockslide"],
		tier: "RUBL",
		doublesTier: "DOU",
	},
	blacephalon: {
		randomBattleMoves: ["mindblown", "fireblast", "shadowball", "hiddenpowerice", "trick", "explosion", "calmmind"],
		randomDoubleBattleMoves: ["willowisp", "fireblast", "shadowball", "hiddenpowerice", "heatwave", "protect"],
		tier: "OU",
		doublesTier: "DUU",
	},
	zeraora: {
		randomBattleMoves: ["plasmafists", "closecombat", "voltswitch", "hiddenpowerice", "knockoff", "grassknot", "workup"],
		randomDoubleBattleMoves: ["plasmafists", "closecombat", "voltswitch", "hiddenpowerice", "knockoff", "grassknot", "fakeout", "protect"],
		tier: "UU",
		doublesTier: "DOU",
	},
	meltan: {
		isNonstandard: "LGPE",
		tier: "Illegal",
	},
	melmetal: {
		isNonstandard: "LGPE",
		tier: "Illegal",
	},
};
